// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'app_database.dart';

// ignore_for_file: type=lint
class $CoursesTable extends Courses with TableInfo<$CoursesTable, Course> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CoursesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, false,
      hasAutoIncrement: true,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('PRIMARY KEY AUTOINCREMENT'));
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
      'name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  @override
  List<GeneratedColumn> get $columns => [id, name];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'courses';
  @override
  VerificationContext validateIntegrity(Insertable<Course> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('name')) {
      context.handle(
          _nameMeta, name.isAcceptableOrUnknown(data['name']!, _nameMeta));
    } else if (isInserting) {
      context.missing(_nameMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Course map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Course(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id'])!,
      name: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name'])!,
    );
  }

  @override
  $CoursesTable createAlias(String alias) {
    return $CoursesTable(attachedDatabase, alias);
  }
}

class Course extends DataClass implements Insertable<Course> {
  final int id;
  final String name;
  const Course({required this.id, required this.name});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['name'] = Variable<String>(name);
    return map;
  }

  CoursesCompanion toCompanion(bool nullToAbsent) {
    return CoursesCompanion(
      id: Value(id),
      name: Value(name),
    );
  }

  factory Course.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Course(
      id: serializer.fromJson<int>(json['id']),
      name: serializer.fromJson<String>(json['name']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'name': serializer.toJson<String>(name),
    };
  }

  Course copyWith({int? id, String? name}) => Course(
        id: id ?? this.id,
        name: name ?? this.name,
      );
  Course copyWithCompanion(CoursesCompanion data) {
    return Course(
      id: data.id.present ? data.id.value : this.id,
      name: data.name.present ? data.name.value : this.name,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Course(')
          ..write('id: $id, ')
          ..write('name: $name')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, name);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Course && other.id == this.id && other.name == this.name);
}

class CoursesCompanion extends UpdateCompanion<Course> {
  final Value<int> id;
  final Value<String> name;
  const CoursesCompanion({
    this.id = const Value.absent(),
    this.name = const Value.absent(),
  });
  CoursesCompanion.insert({
    this.id = const Value.absent(),
    required String name,
  }) : name = Value(name);
  static Insertable<Course> custom({
    Expression<int>? id,
    Expression<String>? name,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (name != null) 'name': name,
    });
  }

  CoursesCompanion copyWith({Value<int>? id, Value<String>? name}) {
    return CoursesCompanion(
      id: id ?? this.id,
      name: name ?? this.name,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CoursesCompanion(')
          ..write('id: $id, ')
          ..write('name: $name')
          ..write(')'))
        .toString();
  }
}

class $TeeBoxTableTable extends TeeBoxTable
    with TableInfo<$TeeBoxTableTable, TeeBox> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $TeeBoxTableTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, false,
      hasAutoIncrement: true,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('PRIMARY KEY AUTOINCREMENT'));
  static const VerificationMeta _courseIdMeta =
      const VerificationMeta('courseId');
  @override
  late final GeneratedColumn<int> courseId = GeneratedColumn<int>(
      'course_id', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: true,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('REFERENCES courses (id)'));
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
      'name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _yardageMeta =
      const VerificationMeta('yardage');
  @override
  late final GeneratedColumn<int> yardage = GeneratedColumn<int>(
      'yardage', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _ratingMeta = const VerificationMeta('rating');
  @override
  late final GeneratedColumn<double> rating = GeneratedColumn<double>(
      'rating', aliasedName, false,
      type: DriftSqlType.double, requiredDuringInsert: true);
  static const VerificationMeta _slopeMeta = const VerificationMeta('slope');
  @override
  late final GeneratedColumn<int> slope = GeneratedColumn<int>(
      'slope', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  @override
  List<GeneratedColumn> get $columns =>
      [id, courseId, name, yardage, rating, slope];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'tee_box_table';
  @override
  VerificationContext validateIntegrity(Insertable<TeeBox> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('course_id')) {
      context.handle(_courseIdMeta,
          courseId.isAcceptableOrUnknown(data['course_id']!, _courseIdMeta));
    } else if (isInserting) {
      context.missing(_courseIdMeta);
    }
    if (data.containsKey('name')) {
      context.handle(
          _nameMeta, name.isAcceptableOrUnknown(data['name']!, _nameMeta));
    } else if (isInserting) {
      context.missing(_nameMeta);
    }
    if (data.containsKey('yardage')) {
      context.handle(_yardageMeta,
          yardage.isAcceptableOrUnknown(data['yardage']!, _yardageMeta));
    } else if (isInserting) {
      context.missing(_yardageMeta);
    }
    if (data.containsKey('rating')) {
      context.handle(_ratingMeta,
          rating.isAcceptableOrUnknown(data['rating']!, _ratingMeta));
    } else if (isInserting) {
      context.missing(_ratingMeta);
    }
    if (data.containsKey('slope')) {
      context.handle(
          _slopeMeta, slope.isAcceptableOrUnknown(data['slope']!, _slopeMeta));
    } else if (isInserting) {
      context.missing(_slopeMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  TeeBox map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return TeeBox(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id'])!,
      courseId: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}course_id'])!,
      name: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name'])!,
      yardage: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}yardage'])!,
      rating: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}rating'])!,
      slope: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}slope'])!,
    );
  }

  @override
  $TeeBoxTableTable createAlias(String alias) {
    return $TeeBoxTableTable(attachedDatabase, alias);
  }
}

class TeeBox extends DataClass implements Insertable<TeeBox> {
  final int id;
  final int courseId;
  final String name;
  final int yardage;
  final double rating;
  final int slope;
  const TeeBox(
      {required this.id,
      required this.courseId,
      required this.name,
      required this.yardage,
      required this.rating,
      required this.slope});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['course_id'] = Variable<int>(courseId);
    map['name'] = Variable<String>(name);
    map['yardage'] = Variable<int>(yardage);
    map['rating'] = Variable<double>(rating);
    map['slope'] = Variable<int>(slope);
    return map;
  }

  TeeBoxTableCompanion toCompanion(bool nullToAbsent) {
    return TeeBoxTableCompanion(
      id: Value(id),
      courseId: Value(courseId),
      name: Value(name),
      yardage: Value(yardage),
      rating: Value(rating),
      slope: Value(slope),
    );
  }

  factory TeeBox.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return TeeBox(
      id: serializer.fromJson<int>(json['id']),
      courseId: serializer.fromJson<int>(json['courseId']),
      name: serializer.fromJson<String>(json['name']),
      yardage: serializer.fromJson<int>(json['yardage']),
      rating: serializer.fromJson<double>(json['rating']),
      slope: serializer.fromJson<int>(json['slope']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'courseId': serializer.toJson<int>(courseId),
      'name': serializer.toJson<String>(name),
      'yardage': serializer.toJson<int>(yardage),
      'rating': serializer.toJson<double>(rating),
      'slope': serializer.toJson<int>(slope),
    };
  }

  TeeBox copyWith(
          {int? id,
          int? courseId,
          String? name,
          int? yardage,
          double? rating,
          int? slope}) =>
      TeeBox(
        id: id ?? this.id,
        courseId: courseId ?? this.courseId,
        name: name ?? this.name,
        yardage: yardage ?? this.yardage,
        rating: rating ?? this.rating,
        slope: slope ?? this.slope,
      );
  TeeBox copyWithCompanion(TeeBoxTableCompanion data) {
    return TeeBox(
      id: data.id.present ? data.id.value : this.id,
      courseId: data.courseId.present ? data.courseId.value : this.courseId,
      name: data.name.present ? data.name.value : this.name,
      yardage: data.yardage.present ? data.yardage.value : this.yardage,
      rating: data.rating.present ? data.rating.value : this.rating,
      slope: data.slope.present ? data.slope.value : this.slope,
    );
  }

  @override
  String toString() {
    return (StringBuffer('TeeBox(')
          ..write('id: $id, ')
          ..write('courseId: $courseId, ')
          ..write('name: $name, ')
          ..write('yardage: $yardage, ')
          ..write('rating: $rating, ')
          ..write('slope: $slope')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, courseId, name, yardage, rating, slope);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is TeeBox &&
          other.id == this.id &&
          other.courseId == this.courseId &&
          other.name == this.name &&
          other.yardage == this.yardage &&
          other.rating == this.rating &&
          other.slope == this.slope);
}

class TeeBoxTableCompanion extends UpdateCompanion<TeeBox> {
  final Value<int> id;
  final Value<int> courseId;
  final Value<String> name;
  final Value<int> yardage;
  final Value<double> rating;
  final Value<int> slope;
  const TeeBoxTableCompanion({
    this.id = const Value.absent(),
    this.courseId = const Value.absent(),
    this.name = const Value.absent(),
    this.yardage = const Value.absent(),
    this.rating = const Value.absent(),
    this.slope = const Value.absent(),
  });
  TeeBoxTableCompanion.insert({
    this.id = const Value.absent(),
    required int courseId,
    required String name,
    required int yardage,
    required double rating,
    required int slope,
  })  : courseId = Value(courseId),
        name = Value(name),
        yardage = Value(yardage),
        rating = Value(rating),
        slope = Value(slope);
  static Insertable<TeeBox> custom({
    Expression<int>? id,
    Expression<int>? courseId,
    Expression<String>? name,
    Expression<int>? yardage,
    Expression<double>? rating,
    Expression<int>? slope,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (courseId != null) 'course_id': courseId,
      if (name != null) 'name': name,
      if (yardage != null) 'yardage': yardage,
      if (rating != null) 'rating': rating,
      if (slope != null) 'slope': slope,
    });
  }

  TeeBoxTableCompanion copyWith(
      {Value<int>? id,
      Value<int>? courseId,
      Value<String>? name,
      Value<int>? yardage,
      Value<double>? rating,
      Value<int>? slope}) {
    return TeeBoxTableCompanion(
      id: id ?? this.id,
      courseId: courseId ?? this.courseId,
      name: name ?? this.name,
      yardage: yardage ?? this.yardage,
      rating: rating ?? this.rating,
      slope: slope ?? this.slope,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (courseId.present) {
      map['course_id'] = Variable<int>(courseId.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    if (yardage.present) {
      map['yardage'] = Variable<int>(yardage.value);
    }
    if (rating.present) {
      map['rating'] = Variable<double>(rating.value);
    }
    if (slope.present) {
      map['slope'] = Variable<int>(slope.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TeeBoxTableCompanion(')
          ..write('id: $id, ')
          ..write('courseId: $courseId, ')
          ..write('name: $name, ')
          ..write('yardage: $yardage, ')
          ..write('rating: $rating, ')
          ..write('slope: $slope')
          ..write(')'))
        .toString();
  }
}

class $RoundsTable extends Rounds with TableInfo<$RoundsTable, Round> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $RoundsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, false,
      hasAutoIncrement: true,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('PRIMARY KEY AUTOINCREMENT'));
  static const VerificationMeta _courseIdMeta =
      const VerificationMeta('courseId');
  @override
  late final GeneratedColumn<int> courseId = GeneratedColumn<int>(
      'course_id', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: true,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('REFERENCES courses (id)'));
  static const VerificationMeta _teeBoxIdMeta =
      const VerificationMeta('teeBoxId');
  @override
  late final GeneratedColumn<int> teeBoxId = GeneratedColumn<int>(
      'tee_box_id', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: true,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('REFERENCES tee_box_table (id)'));
  static const VerificationMeta _dateMeta = const VerificationMeta('date');
  @override
  late final GeneratedColumn<DateTime> date = GeneratedColumn<DateTime>(
      'date', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  static const VerificationMeta _weatherMeta =
      const VerificationMeta('weather');
  @override
  late final GeneratedColumn<String> weather = GeneratedColumn<String>(
      'weather', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _notesMeta = const VerificationMeta('notes');
  @override
  late final GeneratedColumn<String> notes = GeneratedColumn<String>(
      'notes', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _completedMeta =
      const VerificationMeta('completed');
  @override
  late final GeneratedColumn<bool> completed = GeneratedColumn<bool>(
      'completed', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("completed" IN (0, 1))'),
      defaultValue: const Constant(false));
  @override
  List<GeneratedColumn> get $columns =>
      [id, courseId, teeBoxId, date, weather, notes, completed];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'rounds';
  @override
  VerificationContext validateIntegrity(Insertable<Round> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('course_id')) {
      context.handle(_courseIdMeta,
          courseId.isAcceptableOrUnknown(data['course_id']!, _courseIdMeta));
    } else if (isInserting) {
      context.missing(_courseIdMeta);
    }
    if (data.containsKey('tee_box_id')) {
      context.handle(_teeBoxIdMeta,
          teeBoxId.isAcceptableOrUnknown(data['tee_box_id']!, _teeBoxIdMeta));
    } else if (isInserting) {
      context.missing(_teeBoxIdMeta);
    }
    if (data.containsKey('date')) {
      context.handle(
          _dateMeta, date.isAcceptableOrUnknown(data['date']!, _dateMeta));
    }
    if (data.containsKey('weather')) {
      context.handle(_weatherMeta,
          weather.isAcceptableOrUnknown(data['weather']!, _weatherMeta));
    }
    if (data.containsKey('notes')) {
      context.handle(
          _notesMeta, notes.isAcceptableOrUnknown(data['notes']!, _notesMeta));
    }
    if (data.containsKey('completed')) {
      context.handle(_completedMeta,
          completed.isAcceptableOrUnknown(data['completed']!, _completedMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Round map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Round(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id'])!,
      courseId: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}course_id'])!,
      teeBoxId: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}tee_box_id'])!,
      date: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}date'])!,
      weather: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}weather']),
      notes: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}notes']),
      completed: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}completed'])!,
    );
  }

  @override
  $RoundsTable createAlias(String alias) {
    return $RoundsTable(attachedDatabase, alias);
  }
}

class Round extends DataClass implements Insertable<Round> {
  final int id;
  final int courseId;
  final int teeBoxId;
  final DateTime date;
  final String? weather;
  final String? notes;
  final bool completed;
  const Round(
      {required this.id,
      required this.courseId,
      required this.teeBoxId,
      required this.date,
      this.weather,
      this.notes,
      required this.completed});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['course_id'] = Variable<int>(courseId);
    map['tee_box_id'] = Variable<int>(teeBoxId);
    map['date'] = Variable<DateTime>(date);
    if (!nullToAbsent || weather != null) {
      map['weather'] = Variable<String>(weather);
    }
    if (!nullToAbsent || notes != null) {
      map['notes'] = Variable<String>(notes);
    }
    map['completed'] = Variable<bool>(completed);
    return map;
  }

  RoundsCompanion toCompanion(bool nullToAbsent) {
    return RoundsCompanion(
      id: Value(id),
      courseId: Value(courseId),
      teeBoxId: Value(teeBoxId),
      date: Value(date),
      weather: weather == null && nullToAbsent
          ? const Value.absent()
          : Value(weather),
      notes:
          notes == null && nullToAbsent ? const Value.absent() : Value(notes),
      completed: Value(completed),
    );
  }

  factory Round.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Round(
      id: serializer.fromJson<int>(json['id']),
      courseId: serializer.fromJson<int>(json['courseId']),
      teeBoxId: serializer.fromJson<int>(json['teeBoxId']),
      date: serializer.fromJson<DateTime>(json['date']),
      weather: serializer.fromJson<String?>(json['weather']),
      notes: serializer.fromJson<String?>(json['notes']),
      completed: serializer.fromJson<bool>(json['completed']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'courseId': serializer.toJson<int>(courseId),
      'teeBoxId': serializer.toJson<int>(teeBoxId),
      'date': serializer.toJson<DateTime>(date),
      'weather': serializer.toJson<String?>(weather),
      'notes': serializer.toJson<String?>(notes),
      'completed': serializer.toJson<bool>(completed),
    };
  }

  Round copyWith(
          {int? id,
          int? courseId,
          int? teeBoxId,
          DateTime? date,
          Value<String?> weather = const Value.absent(),
          Value<String?> notes = const Value.absent(),
          bool? completed}) =>
      Round(
        id: id ?? this.id,
        courseId: courseId ?? this.courseId,
        teeBoxId: teeBoxId ?? this.teeBoxId,
        date: date ?? this.date,
        weather: weather.present ? weather.value : this.weather,
        notes: notes.present ? notes.value : this.notes,
        completed: completed ?? this.completed,
      );
  Round copyWithCompanion(RoundsCompanion data) {
    return Round(
      id: data.id.present ? data.id.value : this.id,
      courseId: data.courseId.present ? data.courseId.value : this.courseId,
      teeBoxId: data.teeBoxId.present ? data.teeBoxId.value : this.teeBoxId,
      date: data.date.present ? data.date.value : this.date,
      weather: data.weather.present ? data.weather.value : this.weather,
      notes: data.notes.present ? data.notes.value : this.notes,
      completed: data.completed.present ? data.completed.value : this.completed,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Round(')
          ..write('id: $id, ')
          ..write('courseId: $courseId, ')
          ..write('teeBoxId: $teeBoxId, ')
          ..write('date: $date, ')
          ..write('weather: $weather, ')
          ..write('notes: $notes, ')
          ..write('completed: $completed')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, courseId, teeBoxId, date, weather, notes, completed);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Round &&
          other.id == this.id &&
          other.courseId == this.courseId &&
          other.teeBoxId == this.teeBoxId &&
          other.date == this.date &&
          other.weather == this.weather &&
          other.notes == this.notes &&
          other.completed == this.completed);
}

class RoundsCompanion extends UpdateCompanion<Round> {
  final Value<int> id;
  final Value<int> courseId;
  final Value<int> teeBoxId;
  final Value<DateTime> date;
  final Value<String?> weather;
  final Value<String?> notes;
  final Value<bool> completed;
  const RoundsCompanion({
    this.id = const Value.absent(),
    this.courseId = const Value.absent(),
    this.teeBoxId = const Value.absent(),
    this.date = const Value.absent(),
    this.weather = const Value.absent(),
    this.notes = const Value.absent(),
    this.completed = const Value.absent(),
  });
  RoundsCompanion.insert({
    this.id = const Value.absent(),
    required int courseId,
    required int teeBoxId,
    this.date = const Value.absent(),
    this.weather = const Value.absent(),
    this.notes = const Value.absent(),
    this.completed = const Value.absent(),
  })  : courseId = Value(courseId),
        teeBoxId = Value(teeBoxId);
  static Insertable<Round> custom({
    Expression<int>? id,
    Expression<int>? courseId,
    Expression<int>? teeBoxId,
    Expression<DateTime>? date,
    Expression<String>? weather,
    Expression<String>? notes,
    Expression<bool>? completed,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (courseId != null) 'course_id': courseId,
      if (teeBoxId != null) 'tee_box_id': teeBoxId,
      if (date != null) 'date': date,
      if (weather != null) 'weather': weather,
      if (notes != null) 'notes': notes,
      if (completed != null) 'completed': completed,
    });
  }

  RoundsCompanion copyWith(
      {Value<int>? id,
      Value<int>? courseId,
      Value<int>? teeBoxId,
      Value<DateTime>? date,
      Value<String?>? weather,
      Value<String?>? notes,
      Value<bool>? completed}) {
    return RoundsCompanion(
      id: id ?? this.id,
      courseId: courseId ?? this.courseId,
      teeBoxId: teeBoxId ?? this.teeBoxId,
      date: date ?? this.date,
      weather: weather ?? this.weather,
      notes: notes ?? this.notes,
      completed: completed ?? this.completed,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (courseId.present) {
      map['course_id'] = Variable<int>(courseId.value);
    }
    if (teeBoxId.present) {
      map['tee_box_id'] = Variable<int>(teeBoxId.value);
    }
    if (date.present) {
      map['date'] = Variable<DateTime>(date.value);
    }
    if (weather.present) {
      map['weather'] = Variable<String>(weather.value);
    }
    if (notes.present) {
      map['notes'] = Variable<String>(notes.value);
    }
    if (completed.present) {
      map['completed'] = Variable<bool>(completed.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('RoundsCompanion(')
          ..write('id: $id, ')
          ..write('courseId: $courseId, ')
          ..write('teeBoxId: $teeBoxId, ')
          ..write('date: $date, ')
          ..write('weather: $weather, ')
          ..write('notes: $notes, ')
          ..write('completed: $completed')
          ..write(')'))
        .toString();
  }
}

class $CourseHolesTable extends CourseHoles
    with TableInfo<$CourseHolesTable, CourseHole> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CourseHolesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, false,
      hasAutoIncrement: true,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('PRIMARY KEY AUTOINCREMENT'));
  static const VerificationMeta _courseIdMeta =
      const VerificationMeta('courseId');
  @override
  late final GeneratedColumn<int> courseId = GeneratedColumn<int>(
      'course_id', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: true,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('REFERENCES courses (id)'));
  static const VerificationMeta _holeNumberMeta =
      const VerificationMeta('holeNumber');
  @override
  late final GeneratedColumn<int> holeNumber = GeneratedColumn<int>(
      'hole_number', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _parMeta = const VerificationMeta('par');
  @override
  late final GeneratedColumn<int> par = GeneratedColumn<int>(
      'par', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _strokeIndexMeta =
      const VerificationMeta('strokeIndex');
  @override
  late final GeneratedColumn<int> strokeIndex = GeneratedColumn<int>(
      'stroke_index', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, courseId, holeNumber, par, strokeIndex];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'course_holes';
  @override
  VerificationContext validateIntegrity(Insertable<CourseHole> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('course_id')) {
      context.handle(_courseIdMeta,
          courseId.isAcceptableOrUnknown(data['course_id']!, _courseIdMeta));
    } else if (isInserting) {
      context.missing(_courseIdMeta);
    }
    if (data.containsKey('hole_number')) {
      context.handle(
          _holeNumberMeta,
          holeNumber.isAcceptableOrUnknown(
              data['hole_number']!, _holeNumberMeta));
    } else if (isInserting) {
      context.missing(_holeNumberMeta);
    }
    if (data.containsKey('par')) {
      context.handle(
          _parMeta, par.isAcceptableOrUnknown(data['par']!, _parMeta));
    } else if (isInserting) {
      context.missing(_parMeta);
    }
    if (data.containsKey('stroke_index')) {
      context.handle(
          _strokeIndexMeta,
          strokeIndex.isAcceptableOrUnknown(
              data['stroke_index']!, _strokeIndexMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  List<Set<GeneratedColumn>> get uniqueKeys => [
        {courseId, holeNumber},
      ];
  @override
  CourseHole map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CourseHole(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id'])!,
      courseId: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}course_id'])!,
      holeNumber: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}hole_number'])!,
      par: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}par'])!,
      strokeIndex: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}stroke_index']),
    );
  }

  @override
  $CourseHolesTable createAlias(String alias) {
    return $CourseHolesTable(attachedDatabase, alias);
  }
}

class CourseHole extends DataClass implements Insertable<CourseHole> {
  final int id;
  final int courseId;
  final int holeNumber;
  final int par;
  final int? strokeIndex;
  const CourseHole(
      {required this.id,
      required this.courseId,
      required this.holeNumber,
      required this.par,
      this.strokeIndex});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['course_id'] = Variable<int>(courseId);
    map['hole_number'] = Variable<int>(holeNumber);
    map['par'] = Variable<int>(par);
    if (!nullToAbsent || strokeIndex != null) {
      map['stroke_index'] = Variable<int>(strokeIndex);
    }
    return map;
  }

  CourseHolesCompanion toCompanion(bool nullToAbsent) {
    return CourseHolesCompanion(
      id: Value(id),
      courseId: Value(courseId),
      holeNumber: Value(holeNumber),
      par: Value(par),
      strokeIndex: strokeIndex == null && nullToAbsent
          ? const Value.absent()
          : Value(strokeIndex),
    );
  }

  factory CourseHole.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CourseHole(
      id: serializer.fromJson<int>(json['id']),
      courseId: serializer.fromJson<int>(json['courseId']),
      holeNumber: serializer.fromJson<int>(json['holeNumber']),
      par: serializer.fromJson<int>(json['par']),
      strokeIndex: serializer.fromJson<int?>(json['strokeIndex']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'courseId': serializer.toJson<int>(courseId),
      'holeNumber': serializer.toJson<int>(holeNumber),
      'par': serializer.toJson<int>(par),
      'strokeIndex': serializer.toJson<int?>(strokeIndex),
    };
  }

  CourseHole copyWith(
          {int? id,
          int? courseId,
          int? holeNumber,
          int? par,
          Value<int?> strokeIndex = const Value.absent()}) =>
      CourseHole(
        id: id ?? this.id,
        courseId: courseId ?? this.courseId,
        holeNumber: holeNumber ?? this.holeNumber,
        par: par ?? this.par,
        strokeIndex: strokeIndex.present ? strokeIndex.value : this.strokeIndex,
      );
  CourseHole copyWithCompanion(CourseHolesCompanion data) {
    return CourseHole(
      id: data.id.present ? data.id.value : this.id,
      courseId: data.courseId.present ? data.courseId.value : this.courseId,
      holeNumber:
          data.holeNumber.present ? data.holeNumber.value : this.holeNumber,
      par: data.par.present ? data.par.value : this.par,
      strokeIndex:
          data.strokeIndex.present ? data.strokeIndex.value : this.strokeIndex,
    );
  }

  @override
  String toString() {
    return (StringBuffer('CourseHole(')
          ..write('id: $id, ')
          ..write('courseId: $courseId, ')
          ..write('holeNumber: $holeNumber, ')
          ..write('par: $par, ')
          ..write('strokeIndex: $strokeIndex')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, courseId, holeNumber, par, strokeIndex);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CourseHole &&
          other.id == this.id &&
          other.courseId == this.courseId &&
          other.holeNumber == this.holeNumber &&
          other.par == this.par &&
          other.strokeIndex == this.strokeIndex);
}

class CourseHolesCompanion extends UpdateCompanion<CourseHole> {
  final Value<int> id;
  final Value<int> courseId;
  final Value<int> holeNumber;
  final Value<int> par;
  final Value<int?> strokeIndex;
  const CourseHolesCompanion({
    this.id = const Value.absent(),
    this.courseId = const Value.absent(),
    this.holeNumber = const Value.absent(),
    this.par = const Value.absent(),
    this.strokeIndex = const Value.absent(),
  });
  CourseHolesCompanion.insert({
    this.id = const Value.absent(),
    required int courseId,
    required int holeNumber,
    required int par,
    this.strokeIndex = const Value.absent(),
  })  : courseId = Value(courseId),
        holeNumber = Value(holeNumber),
        par = Value(par);
  static Insertable<CourseHole> custom({
    Expression<int>? id,
    Expression<int>? courseId,
    Expression<int>? holeNumber,
    Expression<int>? par,
    Expression<int>? strokeIndex,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (courseId != null) 'course_id': courseId,
      if (holeNumber != null) 'hole_number': holeNumber,
      if (par != null) 'par': par,
      if (strokeIndex != null) 'stroke_index': strokeIndex,
    });
  }

  CourseHolesCompanion copyWith(
      {Value<int>? id,
      Value<int>? courseId,
      Value<int>? holeNumber,
      Value<int>? par,
      Value<int?>? strokeIndex}) {
    return CourseHolesCompanion(
      id: id ?? this.id,
      courseId: courseId ?? this.courseId,
      holeNumber: holeNumber ?? this.holeNumber,
      par: par ?? this.par,
      strokeIndex: strokeIndex ?? this.strokeIndex,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (courseId.present) {
      map['course_id'] = Variable<int>(courseId.value);
    }
    if (holeNumber.present) {
      map['hole_number'] = Variable<int>(holeNumber.value);
    }
    if (par.present) {
      map['par'] = Variable<int>(par.value);
    }
    if (strokeIndex.present) {
      map['stroke_index'] = Variable<int>(strokeIndex.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CourseHolesCompanion(')
          ..write('id: $id, ')
          ..write('courseId: $courseId, ')
          ..write('holeNumber: $holeNumber, ')
          ..write('par: $par, ')
          ..write('strokeIndex: $strokeIndex')
          ..write(')'))
        .toString();
  }
}

class $TeeBoxHolesTable extends TeeBoxHoles
    with TableInfo<$TeeBoxHolesTable, TeeBoxHole> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $TeeBoxHolesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, false,
      hasAutoIncrement: true,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('PRIMARY KEY AUTOINCREMENT'));
  static const VerificationMeta _teeBoxIdMeta =
      const VerificationMeta('teeBoxId');
  @override
  late final GeneratedColumn<int> teeBoxId = GeneratedColumn<int>(
      'tee_box_id', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: true,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('REFERENCES tee_box_table (id)'));
  static const VerificationMeta _holeNumberMeta =
      const VerificationMeta('holeNumber');
  @override
  late final GeneratedColumn<int> holeNumber = GeneratedColumn<int>(
      'hole_number', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _yardageMeta =
      const VerificationMeta('yardage');
  @override
  late final GeneratedColumn<int> yardage = GeneratedColumn<int>(
      'yardage', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, teeBoxId, holeNumber, yardage];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'tee_box_holes';
  @override
  VerificationContext validateIntegrity(Insertable<TeeBoxHole> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('tee_box_id')) {
      context.handle(_teeBoxIdMeta,
          teeBoxId.isAcceptableOrUnknown(data['tee_box_id']!, _teeBoxIdMeta));
    } else if (isInserting) {
      context.missing(_teeBoxIdMeta);
    }
    if (data.containsKey('hole_number')) {
      context.handle(
          _holeNumberMeta,
          holeNumber.isAcceptableOrUnknown(
              data['hole_number']!, _holeNumberMeta));
    } else if (isInserting) {
      context.missing(_holeNumberMeta);
    }
    if (data.containsKey('yardage')) {
      context.handle(_yardageMeta,
          yardage.isAcceptableOrUnknown(data['yardage']!, _yardageMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  List<Set<GeneratedColumn>> get uniqueKeys => [
        {teeBoxId, holeNumber},
      ];
  @override
  TeeBoxHole map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return TeeBoxHole(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id'])!,
      teeBoxId: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}tee_box_id'])!,
      holeNumber: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}hole_number'])!,
      yardage: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}yardage']),
    );
  }

  @override
  $TeeBoxHolesTable createAlias(String alias) {
    return $TeeBoxHolesTable(attachedDatabase, alias);
  }
}

class TeeBoxHole extends DataClass implements Insertable<TeeBoxHole> {
  final int id;
  final int teeBoxId;
  final int holeNumber;
  final int? yardage;
  const TeeBoxHole(
      {required this.id,
      required this.teeBoxId,
      required this.holeNumber,
      this.yardage});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['tee_box_id'] = Variable<int>(teeBoxId);
    map['hole_number'] = Variable<int>(holeNumber);
    if (!nullToAbsent || yardage != null) {
      map['yardage'] = Variable<int>(yardage);
    }
    return map;
  }

  TeeBoxHolesCompanion toCompanion(bool nullToAbsent) {
    return TeeBoxHolesCompanion(
      id: Value(id),
      teeBoxId: Value(teeBoxId),
      holeNumber: Value(holeNumber),
      yardage: yardage == null && nullToAbsent
          ? const Value.absent()
          : Value(yardage),
    );
  }

  factory TeeBoxHole.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return TeeBoxHole(
      id: serializer.fromJson<int>(json['id']),
      teeBoxId: serializer.fromJson<int>(json['teeBoxId']),
      holeNumber: serializer.fromJson<int>(json['holeNumber']),
      yardage: serializer.fromJson<int?>(json['yardage']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'teeBoxId': serializer.toJson<int>(teeBoxId),
      'holeNumber': serializer.toJson<int>(holeNumber),
      'yardage': serializer.toJson<int?>(yardage),
    };
  }

  TeeBoxHole copyWith(
          {int? id,
          int? teeBoxId,
          int? holeNumber,
          Value<int?> yardage = const Value.absent()}) =>
      TeeBoxHole(
        id: id ?? this.id,
        teeBoxId: teeBoxId ?? this.teeBoxId,
        holeNumber: holeNumber ?? this.holeNumber,
        yardage: yardage.present ? yardage.value : this.yardage,
      );
  TeeBoxHole copyWithCompanion(TeeBoxHolesCompanion data) {
    return TeeBoxHole(
      id: data.id.present ? data.id.value : this.id,
      teeBoxId: data.teeBoxId.present ? data.teeBoxId.value : this.teeBoxId,
      holeNumber:
          data.holeNumber.present ? data.holeNumber.value : this.holeNumber,
      yardage: data.yardage.present ? data.yardage.value : this.yardage,
    );
  }

  @override
  String toString() {
    return (StringBuffer('TeeBoxHole(')
          ..write('id: $id, ')
          ..write('teeBoxId: $teeBoxId, ')
          ..write('holeNumber: $holeNumber, ')
          ..write('yardage: $yardage')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, teeBoxId, holeNumber, yardage);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is TeeBoxHole &&
          other.id == this.id &&
          other.teeBoxId == this.teeBoxId &&
          other.holeNumber == this.holeNumber &&
          other.yardage == this.yardage);
}

class TeeBoxHolesCompanion extends UpdateCompanion<TeeBoxHole> {
  final Value<int> id;
  final Value<int> teeBoxId;
  final Value<int> holeNumber;
  final Value<int?> yardage;
  const TeeBoxHolesCompanion({
    this.id = const Value.absent(),
    this.teeBoxId = const Value.absent(),
    this.holeNumber = const Value.absent(),
    this.yardage = const Value.absent(),
  });
  TeeBoxHolesCompanion.insert({
    this.id = const Value.absent(),
    required int teeBoxId,
    required int holeNumber,
    this.yardage = const Value.absent(),
  })  : teeBoxId = Value(teeBoxId),
        holeNumber = Value(holeNumber);
  static Insertable<TeeBoxHole> custom({
    Expression<int>? id,
    Expression<int>? teeBoxId,
    Expression<int>? holeNumber,
    Expression<int>? yardage,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (teeBoxId != null) 'tee_box_id': teeBoxId,
      if (holeNumber != null) 'hole_number': holeNumber,
      if (yardage != null) 'yardage': yardage,
    });
  }

  TeeBoxHolesCompanion copyWith(
      {Value<int>? id,
      Value<int>? teeBoxId,
      Value<int>? holeNumber,
      Value<int?>? yardage}) {
    return TeeBoxHolesCompanion(
      id: id ?? this.id,
      teeBoxId: teeBoxId ?? this.teeBoxId,
      holeNumber: holeNumber ?? this.holeNumber,
      yardage: yardage ?? this.yardage,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (teeBoxId.present) {
      map['tee_box_id'] = Variable<int>(teeBoxId.value);
    }
    if (holeNumber.present) {
      map['hole_number'] = Variable<int>(holeNumber.value);
    }
    if (yardage.present) {
      map['yardage'] = Variable<int>(yardage.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TeeBoxHolesCompanion(')
          ..write('id: $id, ')
          ..write('teeBoxId: $teeBoxId, ')
          ..write('holeNumber: $holeNumber, ')
          ..write('yardage: $yardage')
          ..write(')'))
        .toString();
  }
}

class $HolesTable extends Holes with TableInfo<$HolesTable, Hole> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $HolesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, false,
      hasAutoIncrement: true,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('PRIMARY KEY AUTOINCREMENT'));
  static const VerificationMeta _roundIdMeta =
      const VerificationMeta('roundId');
  @override
  late final GeneratedColumn<int> roundId = GeneratedColumn<int>(
      'round_id', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: true,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('REFERENCES rounds (id)'));
  static const VerificationMeta _holeNumberMeta =
      const VerificationMeta('holeNumber');
  @override
  late final GeneratedColumn<int> holeNumber = GeneratedColumn<int>(
      'hole_number', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _scoreMeta = const VerificationMeta('score');
  @override
  late final GeneratedColumn<int> score = GeneratedColumn<int>(
      'score', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _puttsMeta = const VerificationMeta('putts');
  @override
  late final GeneratedColumn<int> putts = GeneratedColumn<int>(
      'putts', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _penaltiesMeta =
      const VerificationMeta('penalties');
  @override
  late final GeneratedColumn<int> penalties = GeneratedColumn<int>(
      'penalties', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _firMeta = const VerificationMeta('fir');
  @override
  late final GeneratedColumn<String> fir = GeneratedColumn<String>(
      'fir', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _approachLocationMeta =
      const VerificationMeta('approachLocation');
  @override
  late final GeneratedColumn<String> approachLocation = GeneratedColumn<String>(
      'approach_location', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _approachDistanceMeta =
      const VerificationMeta('approachDistance');
  @override
  late final GeneratedColumn<int> approachDistance = GeneratedColumn<int>(
      'approach_distance', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _firstPuttDistanceMeta =
      const VerificationMeta('firstPuttDistance');
  @override
  late final GeneratedColumn<int> firstPuttDistance = GeneratedColumn<int>(
      'first_putt_distance', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        roundId,
        holeNumber,
        score,
        putts,
        penalties,
        fir,
        approachLocation,
        approachDistance,
        firstPuttDistance
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'holes';
  @override
  VerificationContext validateIntegrity(Insertable<Hole> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('round_id')) {
      context.handle(_roundIdMeta,
          roundId.isAcceptableOrUnknown(data['round_id']!, _roundIdMeta));
    } else if (isInserting) {
      context.missing(_roundIdMeta);
    }
    if (data.containsKey('hole_number')) {
      context.handle(
          _holeNumberMeta,
          holeNumber.isAcceptableOrUnknown(
              data['hole_number']!, _holeNumberMeta));
    } else if (isInserting) {
      context.missing(_holeNumberMeta);
    }
    if (data.containsKey('score')) {
      context.handle(
          _scoreMeta, score.isAcceptableOrUnknown(data['score']!, _scoreMeta));
    }
    if (data.containsKey('putts')) {
      context.handle(
          _puttsMeta, putts.isAcceptableOrUnknown(data['putts']!, _puttsMeta));
    }
    if (data.containsKey('penalties')) {
      context.handle(_penaltiesMeta,
          penalties.isAcceptableOrUnknown(data['penalties']!, _penaltiesMeta));
    }
    if (data.containsKey('fir')) {
      context.handle(
          _firMeta, fir.isAcceptableOrUnknown(data['fir']!, _firMeta));
    }
    if (data.containsKey('approach_location')) {
      context.handle(
          _approachLocationMeta,
          approachLocation.isAcceptableOrUnknown(
              data['approach_location']!, _approachLocationMeta));
    }
    if (data.containsKey('approach_distance')) {
      context.handle(
          _approachDistanceMeta,
          approachDistance.isAcceptableOrUnknown(
              data['approach_distance']!, _approachDistanceMeta));
    }
    if (data.containsKey('first_putt_distance')) {
      context.handle(
          _firstPuttDistanceMeta,
          firstPuttDistance.isAcceptableOrUnknown(
              data['first_putt_distance']!, _firstPuttDistanceMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  List<Set<GeneratedColumn>> get uniqueKeys => [
        {roundId, holeNumber},
      ];
  @override
  Hole map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Hole(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id'])!,
      roundId: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}round_id'])!,
      holeNumber: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}hole_number'])!,
      score: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}score']),
      putts: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}putts']),
      penalties: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}penalties']),
      fir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}fir']),
      approachLocation: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}approach_location']),
      approachDistance: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}approach_distance']),
      firstPuttDistance: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}first_putt_distance']),
    );
  }

  @override
  $HolesTable createAlias(String alias) {
    return $HolesTable(attachedDatabase, alias);
  }
}

class Hole extends DataClass implements Insertable<Hole> {
  final int id;
  final int roundId;
  final int holeNumber;
  final int? score;
  final int? putts;
  final int? penalties;
  final String? fir;
  final String? approachLocation;
  final int? approachDistance;
  final int? firstPuttDistance;
  const Hole(
      {required this.id,
      required this.roundId,
      required this.holeNumber,
      this.score,
      this.putts,
      this.penalties,
      this.fir,
      this.approachLocation,
      this.approachDistance,
      this.firstPuttDistance});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['round_id'] = Variable<int>(roundId);
    map['hole_number'] = Variable<int>(holeNumber);
    if (!nullToAbsent || score != null) {
      map['score'] = Variable<int>(score);
    }
    if (!nullToAbsent || putts != null) {
      map['putts'] = Variable<int>(putts);
    }
    if (!nullToAbsent || penalties != null) {
      map['penalties'] = Variable<int>(penalties);
    }
    if (!nullToAbsent || fir != null) {
      map['fir'] = Variable<String>(fir);
    }
    if (!nullToAbsent || approachLocation != null) {
      map['approach_location'] = Variable<String>(approachLocation);
    }
    if (!nullToAbsent || approachDistance != null) {
      map['approach_distance'] = Variable<int>(approachDistance);
    }
    if (!nullToAbsent || firstPuttDistance != null) {
      map['first_putt_distance'] = Variable<int>(firstPuttDistance);
    }
    return map;
  }

  HolesCompanion toCompanion(bool nullToAbsent) {
    return HolesCompanion(
      id: Value(id),
      roundId: Value(roundId),
      holeNumber: Value(holeNumber),
      score:
          score == null && nullToAbsent ? const Value.absent() : Value(score),
      putts:
          putts == null && nullToAbsent ? const Value.absent() : Value(putts),
      penalties: penalties == null && nullToAbsent
          ? const Value.absent()
          : Value(penalties),
      fir: fir == null && nullToAbsent ? const Value.absent() : Value(fir),
      approachLocation: approachLocation == null && nullToAbsent
          ? const Value.absent()
          : Value(approachLocation),
      approachDistance: approachDistance == null && nullToAbsent
          ? const Value.absent()
          : Value(approachDistance),
      firstPuttDistance: firstPuttDistance == null && nullToAbsent
          ? const Value.absent()
          : Value(firstPuttDistance),
    );
  }

  factory Hole.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Hole(
      id: serializer.fromJson<int>(json['id']),
      roundId: serializer.fromJson<int>(json['roundId']),
      holeNumber: serializer.fromJson<int>(json['holeNumber']),
      score: serializer.fromJson<int?>(json['score']),
      putts: serializer.fromJson<int?>(json['putts']),
      penalties: serializer.fromJson<int?>(json['penalties']),
      fir: serializer.fromJson<String?>(json['fir']),
      approachLocation: serializer.fromJson<String?>(json['approachLocation']),
      approachDistance: serializer.fromJson<int?>(json['approachDistance']),
      firstPuttDistance: serializer.fromJson<int?>(json['firstPuttDistance']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'roundId': serializer.toJson<int>(roundId),
      'holeNumber': serializer.toJson<int>(holeNumber),
      'score': serializer.toJson<int?>(score),
      'putts': serializer.toJson<int?>(putts),
      'penalties': serializer.toJson<int?>(penalties),
      'fir': serializer.toJson<String?>(fir),
      'approachLocation': serializer.toJson<String?>(approachLocation),
      'approachDistance': serializer.toJson<int?>(approachDistance),
      'firstPuttDistance': serializer.toJson<int?>(firstPuttDistance),
    };
  }

  Hole copyWith(
          {int? id,
          int? roundId,
          int? holeNumber,
          Value<int?> score = const Value.absent(),
          Value<int?> putts = const Value.absent(),
          Value<int?> penalties = const Value.absent(),
          Value<String?> fir = const Value.absent(),
          Value<String?> approachLocation = const Value.absent(),
          Value<int?> approachDistance = const Value.absent(),
          Value<int?> firstPuttDistance = const Value.absent()}) =>
      Hole(
        id: id ?? this.id,
        roundId: roundId ?? this.roundId,
        holeNumber: holeNumber ?? this.holeNumber,
        score: score.present ? score.value : this.score,
        putts: putts.present ? putts.value : this.putts,
        penalties: penalties.present ? penalties.value : this.penalties,
        fir: fir.present ? fir.value : this.fir,
        approachLocation: approachLocation.present
            ? approachLocation.value
            : this.approachLocation,
        approachDistance: approachDistance.present
            ? approachDistance.value
            : this.approachDistance,
        firstPuttDistance: firstPuttDistance.present
            ? firstPuttDistance.value
            : this.firstPuttDistance,
      );
  Hole copyWithCompanion(HolesCompanion data) {
    return Hole(
      id: data.id.present ? data.id.value : this.id,
      roundId: data.roundId.present ? data.roundId.value : this.roundId,
      holeNumber:
          data.holeNumber.present ? data.holeNumber.value : this.holeNumber,
      score: data.score.present ? data.score.value : this.score,
      putts: data.putts.present ? data.putts.value : this.putts,
      penalties: data.penalties.present ? data.penalties.value : this.penalties,
      fir: data.fir.present ? data.fir.value : this.fir,
      approachLocation: data.approachLocation.present
          ? data.approachLocation.value
          : this.approachLocation,
      approachDistance: data.approachDistance.present
          ? data.approachDistance.value
          : this.approachDistance,
      firstPuttDistance: data.firstPuttDistance.present
          ? data.firstPuttDistance.value
          : this.firstPuttDistance,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Hole(')
          ..write('id: $id, ')
          ..write('roundId: $roundId, ')
          ..write('holeNumber: $holeNumber, ')
          ..write('score: $score, ')
          ..write('putts: $putts, ')
          ..write('penalties: $penalties, ')
          ..write('fir: $fir, ')
          ..write('approachLocation: $approachLocation, ')
          ..write('approachDistance: $approachDistance, ')
          ..write('firstPuttDistance: $firstPuttDistance')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, roundId, holeNumber, score, putts,
      penalties, fir, approachLocation, approachDistance, firstPuttDistance);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Hole &&
          other.id == this.id &&
          other.roundId == this.roundId &&
          other.holeNumber == this.holeNumber &&
          other.score == this.score &&
          other.putts == this.putts &&
          other.penalties == this.penalties &&
          other.fir == this.fir &&
          other.approachLocation == this.approachLocation &&
          other.approachDistance == this.approachDistance &&
          other.firstPuttDistance == this.firstPuttDistance);
}

class HolesCompanion extends UpdateCompanion<Hole> {
  final Value<int> id;
  final Value<int> roundId;
  final Value<int> holeNumber;
  final Value<int?> score;
  final Value<int?> putts;
  final Value<int?> penalties;
  final Value<String?> fir;
  final Value<String?> approachLocation;
  final Value<int?> approachDistance;
  final Value<int?> firstPuttDistance;
  const HolesCompanion({
    this.id = const Value.absent(),
    this.roundId = const Value.absent(),
    this.holeNumber = const Value.absent(),
    this.score = const Value.absent(),
    this.putts = const Value.absent(),
    this.penalties = const Value.absent(),
    this.fir = const Value.absent(),
    this.approachLocation = const Value.absent(),
    this.approachDistance = const Value.absent(),
    this.firstPuttDistance = const Value.absent(),
  });
  HolesCompanion.insert({
    this.id = const Value.absent(),
    required int roundId,
    required int holeNumber,
    this.score = const Value.absent(),
    this.putts = const Value.absent(),
    this.penalties = const Value.absent(),
    this.fir = const Value.absent(),
    this.approachLocation = const Value.absent(),
    this.approachDistance = const Value.absent(),
    this.firstPuttDistance = const Value.absent(),
  })  : roundId = Value(roundId),
        holeNumber = Value(holeNumber);
  static Insertable<Hole> custom({
    Expression<int>? id,
    Expression<int>? roundId,
    Expression<int>? holeNumber,
    Expression<int>? score,
    Expression<int>? putts,
    Expression<int>? penalties,
    Expression<String>? fir,
    Expression<String>? approachLocation,
    Expression<int>? approachDistance,
    Expression<int>? firstPuttDistance,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (roundId != null) 'round_id': roundId,
      if (holeNumber != null) 'hole_number': holeNumber,
      if (score != null) 'score': score,
      if (putts != null) 'putts': putts,
      if (penalties != null) 'penalties': penalties,
      if (fir != null) 'fir': fir,
      if (approachLocation != null) 'approach_location': approachLocation,
      if (approachDistance != null) 'approach_distance': approachDistance,
      if (firstPuttDistance != null) 'first_putt_distance': firstPuttDistance,
    });
  }

  HolesCompanion copyWith(
      {Value<int>? id,
      Value<int>? roundId,
      Value<int>? holeNumber,
      Value<int?>? score,
      Value<int?>? putts,
      Value<int?>? penalties,
      Value<String?>? fir,
      Value<String?>? approachLocation,
      Value<int?>? approachDistance,
      Value<int?>? firstPuttDistance}) {
    return HolesCompanion(
      id: id ?? this.id,
      roundId: roundId ?? this.roundId,
      holeNumber: holeNumber ?? this.holeNumber,
      score: score ?? this.score,
      putts: putts ?? this.putts,
      penalties: penalties ?? this.penalties,
      fir: fir ?? this.fir,
      approachLocation: approachLocation ?? this.approachLocation,
      approachDistance: approachDistance ?? this.approachDistance,
      firstPuttDistance: firstPuttDistance ?? this.firstPuttDistance,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (roundId.present) {
      map['round_id'] = Variable<int>(roundId.value);
    }
    if (holeNumber.present) {
      map['hole_number'] = Variable<int>(holeNumber.value);
    }
    if (score.present) {
      map['score'] = Variable<int>(score.value);
    }
    if (putts.present) {
      map['putts'] = Variable<int>(putts.value);
    }
    if (penalties.present) {
      map['penalties'] = Variable<int>(penalties.value);
    }
    if (fir.present) {
      map['fir'] = Variable<String>(fir.value);
    }
    if (approachLocation.present) {
      map['approach_location'] = Variable<String>(approachLocation.value);
    }
    if (approachDistance.present) {
      map['approach_distance'] = Variable<int>(approachDistance.value);
    }
    if (firstPuttDistance.present) {
      map['first_putt_distance'] = Variable<int>(firstPuttDistance.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('HolesCompanion(')
          ..write('id: $id, ')
          ..write('roundId: $roundId, ')
          ..write('holeNumber: $holeNumber, ')
          ..write('score: $score, ')
          ..write('putts: $putts, ')
          ..write('penalties: $penalties, ')
          ..write('fir: $fir, ')
          ..write('approachLocation: $approachLocation, ')
          ..write('approachDistance: $approachDistance, ')
          ..write('firstPuttDistance: $firstPuttDistance')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  $AppDatabaseManager get managers => $AppDatabaseManager(this);
  late final $CoursesTable courses = $CoursesTable(this);
  late final $TeeBoxTableTable teeBoxTable = $TeeBoxTableTable(this);
  late final $RoundsTable rounds = $RoundsTable(this);
  late final $CourseHolesTable courseHoles = $CourseHolesTable(this);
  late final $TeeBoxHolesTable teeBoxHoles = $TeeBoxHolesTable(this);
  late final $HolesTable holes = $HolesTable(this);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities =>
      [courses, teeBoxTable, rounds, courseHoles, teeBoxHoles, holes];
}

typedef $$CoursesTableCreateCompanionBuilder = CoursesCompanion Function({
  Value<int> id,
  required String name,
});
typedef $$CoursesTableUpdateCompanionBuilder = CoursesCompanion Function({
  Value<int> id,
  Value<String> name,
});

final class $$CoursesTableReferences
    extends BaseReferences<_$AppDatabase, $CoursesTable, Course> {
  $$CoursesTableReferences(super.$_db, super.$_table, super.$_typedResult);

  static MultiTypedResultKey<$TeeBoxTableTable, List<TeeBox>>
      _teeBoxTableRefsTable(_$AppDatabase db) =>
          MultiTypedResultKey.fromTable(db.teeBoxTable,
              aliasName:
                  $_aliasNameGenerator(db.courses.id, db.teeBoxTable.courseId));

  $$TeeBoxTableTableProcessedTableManager get teeBoxTableRefs {
    final manager = $$TeeBoxTableTableTableManager($_db, $_db.teeBoxTable)
        .filter((f) => f.courseId.id.sqlEquals($_itemColumn<int>('id')!));

    final cache = $_typedResult.readTableOrNull(_teeBoxTableRefsTable($_db));
    return ProcessedTableManager(
        manager.$state.copyWith(prefetchedData: cache));
  }

  static MultiTypedResultKey<$RoundsTable, List<Round>> _roundsRefsTable(
          _$AppDatabase db) =>
      MultiTypedResultKey.fromTable(db.rounds,
          aliasName: $_aliasNameGenerator(db.courses.id, db.rounds.courseId));

  $$RoundsTableProcessedTableManager get roundsRefs {
    final manager = $$RoundsTableTableManager($_db, $_db.rounds)
        .filter((f) => f.courseId.id.sqlEquals($_itemColumn<int>('id')!));

    final cache = $_typedResult.readTableOrNull(_roundsRefsTable($_db));
    return ProcessedTableManager(
        manager.$state.copyWith(prefetchedData: cache));
  }

  static MultiTypedResultKey<$CourseHolesTable, List<CourseHole>>
      _courseHolesRefsTable(_$AppDatabase db) =>
          MultiTypedResultKey.fromTable(db.courseHoles,
              aliasName:
                  $_aliasNameGenerator(db.courses.id, db.courseHoles.courseId));

  $$CourseHolesTableProcessedTableManager get courseHolesRefs {
    final manager = $$CourseHolesTableTableManager($_db, $_db.courseHoles)
        .filter((f) => f.courseId.id.sqlEquals($_itemColumn<int>('id')!));

    final cache = $_typedResult.readTableOrNull(_courseHolesRefsTable($_db));
    return ProcessedTableManager(
        manager.$state.copyWith(prefetchedData: cache));
  }
}

class $$CoursesTableFilterComposer
    extends Composer<_$AppDatabase, $CoursesTable> {
  $$CoursesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnFilters(column));

  Expression<bool> teeBoxTableRefs(
      Expression<bool> Function($$TeeBoxTableTableFilterComposer f) f) {
    final $$TeeBoxTableTableFilterComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.id,
        referencedTable: $db.teeBoxTable,
        getReferencedColumn: (t) => t.courseId,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$TeeBoxTableTableFilterComposer(
              $db: $db,
              $table: $db.teeBoxTable,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return f(composer);
  }

  Expression<bool> roundsRefs(
      Expression<bool> Function($$RoundsTableFilterComposer f) f) {
    final $$RoundsTableFilterComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.id,
        referencedTable: $db.rounds,
        getReferencedColumn: (t) => t.courseId,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$RoundsTableFilterComposer(
              $db: $db,
              $table: $db.rounds,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return f(composer);
  }

  Expression<bool> courseHolesRefs(
      Expression<bool> Function($$CourseHolesTableFilterComposer f) f) {
    final $$CourseHolesTableFilterComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.id,
        referencedTable: $db.courseHoles,
        getReferencedColumn: (t) => t.courseId,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$CourseHolesTableFilterComposer(
              $db: $db,
              $table: $db.courseHoles,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return f(composer);
  }
}

class $$CoursesTableOrderingComposer
    extends Composer<_$AppDatabase, $CoursesTable> {
  $$CoursesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnOrderings(column));
}

class $$CoursesTableAnnotationComposer
    extends Composer<_$AppDatabase, $CoursesTable> {
  $$CoursesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get name =>
      $composableBuilder(column: $table.name, builder: (column) => column);

  Expression<T> teeBoxTableRefs<T extends Object>(
      Expression<T> Function($$TeeBoxTableTableAnnotationComposer a) f) {
    final $$TeeBoxTableTableAnnotationComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.id,
        referencedTable: $db.teeBoxTable,
        getReferencedColumn: (t) => t.courseId,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$TeeBoxTableTableAnnotationComposer(
              $db: $db,
              $table: $db.teeBoxTable,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return f(composer);
  }

  Expression<T> roundsRefs<T extends Object>(
      Expression<T> Function($$RoundsTableAnnotationComposer a) f) {
    final $$RoundsTableAnnotationComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.id,
        referencedTable: $db.rounds,
        getReferencedColumn: (t) => t.courseId,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$RoundsTableAnnotationComposer(
              $db: $db,
              $table: $db.rounds,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return f(composer);
  }

  Expression<T> courseHolesRefs<T extends Object>(
      Expression<T> Function($$CourseHolesTableAnnotationComposer a) f) {
    final $$CourseHolesTableAnnotationComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.id,
        referencedTable: $db.courseHoles,
        getReferencedColumn: (t) => t.courseId,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$CourseHolesTableAnnotationComposer(
              $db: $db,
              $table: $db.courseHoles,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return f(composer);
  }
}

class $$CoursesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $CoursesTable,
    Course,
    $$CoursesTableFilterComposer,
    $$CoursesTableOrderingComposer,
    $$CoursesTableAnnotationComposer,
    $$CoursesTableCreateCompanionBuilder,
    $$CoursesTableUpdateCompanionBuilder,
    (Course, $$CoursesTableReferences),
    Course,
    PrefetchHooks Function(
        {bool teeBoxTableRefs, bool roundsRefs, bool courseHolesRefs})> {
  $$CoursesTableTableManager(_$AppDatabase db, $CoursesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$CoursesTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$CoursesTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$CoursesTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<int> id = const Value.absent(),
            Value<String> name = const Value.absent(),
          }) =>
              CoursesCompanion(
            id: id,
            name: name,
          ),
          createCompanionCallback: ({
            Value<int> id = const Value.absent(),
            required String name,
          }) =>
              CoursesCompanion.insert(
            id: id,
            name: name,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) =>
                  (e.readTable(table), $$CoursesTableReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: (
              {teeBoxTableRefs = false,
              roundsRefs = false,
              courseHolesRefs = false}) {
            return PrefetchHooks(
              db: db,
              explicitlyWatchedTables: [
                if (teeBoxTableRefs) db.teeBoxTable,
                if (roundsRefs) db.rounds,
                if (courseHolesRefs) db.courseHoles
              ],
              addJoins: null,
              getPrefetchedDataCallback: (items) async {
                return [
                  if (teeBoxTableRefs)
                    await $_getPrefetchedData<Course, $CoursesTable, TeeBox>(
                        currentTable: table,
                        referencedTable:
                            $$CoursesTableReferences._teeBoxTableRefsTable(db),
                        managerFromTypedResult: (p0) =>
                            $$CoursesTableReferences(db, table, p0)
                                .teeBoxTableRefs,
                        referencedItemsForCurrentItem: (item,
                                referencedItems) =>
                            referencedItems.where((e) => e.courseId == item.id),
                        typedResults: items),
                  if (roundsRefs)
                    await $_getPrefetchedData<Course, $CoursesTable, Round>(
                        currentTable: table,
                        referencedTable:
                            $$CoursesTableReferences._roundsRefsTable(db),
                        managerFromTypedResult: (p0) =>
                            $$CoursesTableReferences(db, table, p0).roundsRefs,
                        referencedItemsForCurrentItem: (item,
                                referencedItems) =>
                            referencedItems.where((e) => e.courseId == item.id),
                        typedResults: items),
                  if (courseHolesRefs)
                    await $_getPrefetchedData<Course, $CoursesTable,
                            CourseHole>(
                        currentTable: table,
                        referencedTable:
                            $$CoursesTableReferences._courseHolesRefsTable(db),
                        managerFromTypedResult: (p0) =>
                            $$CoursesTableReferences(db, table, p0)
                                .courseHolesRefs,
                        referencedItemsForCurrentItem: (item,
                                referencedItems) =>
                            referencedItems.where((e) => e.courseId == item.id),
                        typedResults: items)
                ];
              },
            );
          },
        ));
}

typedef $$CoursesTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $CoursesTable,
    Course,
    $$CoursesTableFilterComposer,
    $$CoursesTableOrderingComposer,
    $$CoursesTableAnnotationComposer,
    $$CoursesTableCreateCompanionBuilder,
    $$CoursesTableUpdateCompanionBuilder,
    (Course, $$CoursesTableReferences),
    Course,
    PrefetchHooks Function(
        {bool teeBoxTableRefs, bool roundsRefs, bool courseHolesRefs})>;
typedef $$TeeBoxTableTableCreateCompanionBuilder = TeeBoxTableCompanion
    Function({
  Value<int> id,
  required int courseId,
  required String name,
  required int yardage,
  required double rating,
  required int slope,
});
typedef $$TeeBoxTableTableUpdateCompanionBuilder = TeeBoxTableCompanion
    Function({
  Value<int> id,
  Value<int> courseId,
  Value<String> name,
  Value<int> yardage,
  Value<double> rating,
  Value<int> slope,
});

final class $$TeeBoxTableTableReferences
    extends BaseReferences<_$AppDatabase, $TeeBoxTableTable, TeeBox> {
  $$TeeBoxTableTableReferences(super.$_db, super.$_table, super.$_typedResult);

  static $CoursesTable _courseIdTable(_$AppDatabase db) =>
      db.courses.createAlias(
          $_aliasNameGenerator(db.teeBoxTable.courseId, db.courses.id));

  $$CoursesTableProcessedTableManager get courseId {
    final $_column = $_itemColumn<int>('course_id')!;

    final manager = $$CoursesTableTableManager($_db, $_db.courses)
        .filter((f) => f.id.sqlEquals($_column));
    final item = $_typedResult.readTableOrNull(_courseIdTable($_db));
    if (item == null) return manager;
    return ProcessedTableManager(
        manager.$state.copyWith(prefetchedData: [item]));
  }

  static MultiTypedResultKey<$RoundsTable, List<Round>> _roundsRefsTable(
          _$AppDatabase db) =>
      MultiTypedResultKey.fromTable(db.rounds,
          aliasName:
              $_aliasNameGenerator(db.teeBoxTable.id, db.rounds.teeBoxId));

  $$RoundsTableProcessedTableManager get roundsRefs {
    final manager = $$RoundsTableTableManager($_db, $_db.rounds)
        .filter((f) => f.teeBoxId.id.sqlEquals($_itemColumn<int>('id')!));

    final cache = $_typedResult.readTableOrNull(_roundsRefsTable($_db));
    return ProcessedTableManager(
        manager.$state.copyWith(prefetchedData: cache));
  }

  static MultiTypedResultKey<$TeeBoxHolesTable, List<TeeBoxHole>>
      _teeBoxHolesRefsTable(_$AppDatabase db) => MultiTypedResultKey.fromTable(
          db.teeBoxHoles,
          aliasName:
              $_aliasNameGenerator(db.teeBoxTable.id, db.teeBoxHoles.teeBoxId));

  $$TeeBoxHolesTableProcessedTableManager get teeBoxHolesRefs {
    final manager = $$TeeBoxHolesTableTableManager($_db, $_db.teeBoxHoles)
        .filter((f) => f.teeBoxId.id.sqlEquals($_itemColumn<int>('id')!));

    final cache = $_typedResult.readTableOrNull(_teeBoxHolesRefsTable($_db));
    return ProcessedTableManager(
        manager.$state.copyWith(prefetchedData: cache));
  }
}

class $$TeeBoxTableTableFilterComposer
    extends Composer<_$AppDatabase, $TeeBoxTableTable> {
  $$TeeBoxTableTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get yardage => $composableBuilder(
      column: $table.yardage, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get rating => $composableBuilder(
      column: $table.rating, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get slope => $composableBuilder(
      column: $table.slope, builder: (column) => ColumnFilters(column));

  $$CoursesTableFilterComposer get courseId {
    final $$CoursesTableFilterComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.courseId,
        referencedTable: $db.courses,
        getReferencedColumn: (t) => t.id,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$CoursesTableFilterComposer(
              $db: $db,
              $table: $db.courses,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return composer;
  }

  Expression<bool> roundsRefs(
      Expression<bool> Function($$RoundsTableFilterComposer f) f) {
    final $$RoundsTableFilterComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.id,
        referencedTable: $db.rounds,
        getReferencedColumn: (t) => t.teeBoxId,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$RoundsTableFilterComposer(
              $db: $db,
              $table: $db.rounds,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return f(composer);
  }

  Expression<bool> teeBoxHolesRefs(
      Expression<bool> Function($$TeeBoxHolesTableFilterComposer f) f) {
    final $$TeeBoxHolesTableFilterComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.id,
        referencedTable: $db.teeBoxHoles,
        getReferencedColumn: (t) => t.teeBoxId,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$TeeBoxHolesTableFilterComposer(
              $db: $db,
              $table: $db.teeBoxHoles,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return f(composer);
  }
}

class $$TeeBoxTableTableOrderingComposer
    extends Composer<_$AppDatabase, $TeeBoxTableTable> {
  $$TeeBoxTableTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get yardage => $composableBuilder(
      column: $table.yardage, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get rating => $composableBuilder(
      column: $table.rating, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get slope => $composableBuilder(
      column: $table.slope, builder: (column) => ColumnOrderings(column));

  $$CoursesTableOrderingComposer get courseId {
    final $$CoursesTableOrderingComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.courseId,
        referencedTable: $db.courses,
        getReferencedColumn: (t) => t.id,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$CoursesTableOrderingComposer(
              $db: $db,
              $table: $db.courses,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return composer;
  }
}

class $$TeeBoxTableTableAnnotationComposer
    extends Composer<_$AppDatabase, $TeeBoxTableTable> {
  $$TeeBoxTableTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get name =>
      $composableBuilder(column: $table.name, builder: (column) => column);

  GeneratedColumn<int> get yardage =>
      $composableBuilder(column: $table.yardage, builder: (column) => column);

  GeneratedColumn<double> get rating =>
      $composableBuilder(column: $table.rating, builder: (column) => column);

  GeneratedColumn<int> get slope =>
      $composableBuilder(column: $table.slope, builder: (column) => column);

  $$CoursesTableAnnotationComposer get courseId {
    final $$CoursesTableAnnotationComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.courseId,
        referencedTable: $db.courses,
        getReferencedColumn: (t) => t.id,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$CoursesTableAnnotationComposer(
              $db: $db,
              $table: $db.courses,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return composer;
  }

  Expression<T> roundsRefs<T extends Object>(
      Expression<T> Function($$RoundsTableAnnotationComposer a) f) {
    final $$RoundsTableAnnotationComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.id,
        referencedTable: $db.rounds,
        getReferencedColumn: (t) => t.teeBoxId,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$RoundsTableAnnotationComposer(
              $db: $db,
              $table: $db.rounds,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return f(composer);
  }

  Expression<T> teeBoxHolesRefs<T extends Object>(
      Expression<T> Function($$TeeBoxHolesTableAnnotationComposer a) f) {
    final $$TeeBoxHolesTableAnnotationComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.id,
        referencedTable: $db.teeBoxHoles,
        getReferencedColumn: (t) => t.teeBoxId,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$TeeBoxHolesTableAnnotationComposer(
              $db: $db,
              $table: $db.teeBoxHoles,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return f(composer);
  }
}

class $$TeeBoxTableTableTableManager extends RootTableManager<
    _$AppDatabase,
    $TeeBoxTableTable,
    TeeBox,
    $$TeeBoxTableTableFilterComposer,
    $$TeeBoxTableTableOrderingComposer,
    $$TeeBoxTableTableAnnotationComposer,
    $$TeeBoxTableTableCreateCompanionBuilder,
    $$TeeBoxTableTableUpdateCompanionBuilder,
    (TeeBox, $$TeeBoxTableTableReferences),
    TeeBox,
    PrefetchHooks Function(
        {bool courseId, bool roundsRefs, bool teeBoxHolesRefs})> {
  $$TeeBoxTableTableTableManager(_$AppDatabase db, $TeeBoxTableTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$TeeBoxTableTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$TeeBoxTableTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$TeeBoxTableTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<int> id = const Value.absent(),
            Value<int> courseId = const Value.absent(),
            Value<String> name = const Value.absent(),
            Value<int> yardage = const Value.absent(),
            Value<double> rating = const Value.absent(),
            Value<int> slope = const Value.absent(),
          }) =>
              TeeBoxTableCompanion(
            id: id,
            courseId: courseId,
            name: name,
            yardage: yardage,
            rating: rating,
            slope: slope,
          ),
          createCompanionCallback: ({
            Value<int> id = const Value.absent(),
            required int courseId,
            required String name,
            required int yardage,
            required double rating,
            required int slope,
          }) =>
              TeeBoxTableCompanion.insert(
            id: id,
            courseId: courseId,
            name: name,
            yardage: yardage,
            rating: rating,
            slope: slope,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (
                    e.readTable(table),
                    $$TeeBoxTableTableReferences(db, table, e)
                  ))
              .toList(),
          prefetchHooksCallback: (
              {courseId = false, roundsRefs = false, teeBoxHolesRefs = false}) {
            return PrefetchHooks(
              db: db,
              explicitlyWatchedTables: [
                if (roundsRefs) db.rounds,
                if (teeBoxHolesRefs) db.teeBoxHoles
              ],
              addJoins: <
                  T extends TableManagerState<
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic>>(state) {
                if (courseId) {
                  state = state.withJoin(
                    currentTable: table,
                    currentColumn: table.courseId,
                    referencedTable:
                        $$TeeBoxTableTableReferences._courseIdTable(db),
                    referencedColumn:
                        $$TeeBoxTableTableReferences._courseIdTable(db).id,
                  ) as T;
                }

                return state;
              },
              getPrefetchedDataCallback: (items) async {
                return [
                  if (roundsRefs)
                    await $_getPrefetchedData<TeeBox, $TeeBoxTableTable, Round>(
                        currentTable: table,
                        referencedTable:
                            $$TeeBoxTableTableReferences._roundsRefsTable(db),
                        managerFromTypedResult: (p0) =>
                            $$TeeBoxTableTableReferences(db, table, p0)
                                .roundsRefs,
                        referencedItemsForCurrentItem: (item,
                                referencedItems) =>
                            referencedItems.where((e) => e.teeBoxId == item.id),
                        typedResults: items),
                  if (teeBoxHolesRefs)
                    await $_getPrefetchedData<TeeBox, $TeeBoxTableTable,
                            TeeBoxHole>(
                        currentTable: table,
                        referencedTable: $$TeeBoxTableTableReferences
                            ._teeBoxHolesRefsTable(db),
                        managerFromTypedResult: (p0) =>
                            $$TeeBoxTableTableReferences(db, table, p0)
                                .teeBoxHolesRefs,
                        referencedItemsForCurrentItem: (item,
                                referencedItems) =>
                            referencedItems.where((e) => e.teeBoxId == item.id),
                        typedResults: items)
                ];
              },
            );
          },
        ));
}

typedef $$TeeBoxTableTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $TeeBoxTableTable,
    TeeBox,
    $$TeeBoxTableTableFilterComposer,
    $$TeeBoxTableTableOrderingComposer,
    $$TeeBoxTableTableAnnotationComposer,
    $$TeeBoxTableTableCreateCompanionBuilder,
    $$TeeBoxTableTableUpdateCompanionBuilder,
    (TeeBox, $$TeeBoxTableTableReferences),
    TeeBox,
    PrefetchHooks Function(
        {bool courseId, bool roundsRefs, bool teeBoxHolesRefs})>;
typedef $$RoundsTableCreateCompanionBuilder = RoundsCompanion Function({
  Value<int> id,
  required int courseId,
  required int teeBoxId,
  Value<DateTime> date,
  Value<String?> weather,
  Value<String?> notes,
  Value<bool> completed,
});
typedef $$RoundsTableUpdateCompanionBuilder = RoundsCompanion Function({
  Value<int> id,
  Value<int> courseId,
  Value<int> teeBoxId,
  Value<DateTime> date,
  Value<String?> weather,
  Value<String?> notes,
  Value<bool> completed,
});

final class $$RoundsTableReferences
    extends BaseReferences<_$AppDatabase, $RoundsTable, Round> {
  $$RoundsTableReferences(super.$_db, super.$_table, super.$_typedResult);

  static $CoursesTable _courseIdTable(_$AppDatabase db) => db.courses
      .createAlias($_aliasNameGenerator(db.rounds.courseId, db.courses.id));

  $$CoursesTableProcessedTableManager get courseId {
    final $_column = $_itemColumn<int>('course_id')!;

    final manager = $$CoursesTableTableManager($_db, $_db.courses)
        .filter((f) => f.id.sqlEquals($_column));
    final item = $_typedResult.readTableOrNull(_courseIdTable($_db));
    if (item == null) return manager;
    return ProcessedTableManager(
        manager.$state.copyWith(prefetchedData: [item]));
  }

  static $TeeBoxTableTable _teeBoxIdTable(_$AppDatabase db) => db.teeBoxTable
      .createAlias($_aliasNameGenerator(db.rounds.teeBoxId, db.teeBoxTable.id));

  $$TeeBoxTableTableProcessedTableManager get teeBoxId {
    final $_column = $_itemColumn<int>('tee_box_id')!;

    final manager = $$TeeBoxTableTableTableManager($_db, $_db.teeBoxTable)
        .filter((f) => f.id.sqlEquals($_column));
    final item = $_typedResult.readTableOrNull(_teeBoxIdTable($_db));
    if (item == null) return manager;
    return ProcessedTableManager(
        manager.$state.copyWith(prefetchedData: [item]));
  }

  static MultiTypedResultKey<$HolesTable, List<Hole>> _holesRefsTable(
          _$AppDatabase db) =>
      MultiTypedResultKey.fromTable(db.holes,
          aliasName: $_aliasNameGenerator(db.rounds.id, db.holes.roundId));

  $$HolesTableProcessedTableManager get holesRefs {
    final manager = $$HolesTableTableManager($_db, $_db.holes)
        .filter((f) => f.roundId.id.sqlEquals($_itemColumn<int>('id')!));

    final cache = $_typedResult.readTableOrNull(_holesRefsTable($_db));
    return ProcessedTableManager(
        manager.$state.copyWith(prefetchedData: cache));
  }
}

class $$RoundsTableFilterComposer
    extends Composer<_$AppDatabase, $RoundsTable> {
  $$RoundsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get date => $composableBuilder(
      column: $table.date, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get weather => $composableBuilder(
      column: $table.weather, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get notes => $composableBuilder(
      column: $table.notes, builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get completed => $composableBuilder(
      column: $table.completed, builder: (column) => ColumnFilters(column));

  $$CoursesTableFilterComposer get courseId {
    final $$CoursesTableFilterComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.courseId,
        referencedTable: $db.courses,
        getReferencedColumn: (t) => t.id,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$CoursesTableFilterComposer(
              $db: $db,
              $table: $db.courses,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return composer;
  }

  $$TeeBoxTableTableFilterComposer get teeBoxId {
    final $$TeeBoxTableTableFilterComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.teeBoxId,
        referencedTable: $db.teeBoxTable,
        getReferencedColumn: (t) => t.id,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$TeeBoxTableTableFilterComposer(
              $db: $db,
              $table: $db.teeBoxTable,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return composer;
  }

  Expression<bool> holesRefs(
      Expression<bool> Function($$HolesTableFilterComposer f) f) {
    final $$HolesTableFilterComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.id,
        referencedTable: $db.holes,
        getReferencedColumn: (t) => t.roundId,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$HolesTableFilterComposer(
              $db: $db,
              $table: $db.holes,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return f(composer);
  }
}

class $$RoundsTableOrderingComposer
    extends Composer<_$AppDatabase, $RoundsTable> {
  $$RoundsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get date => $composableBuilder(
      column: $table.date, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get weather => $composableBuilder(
      column: $table.weather, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get notes => $composableBuilder(
      column: $table.notes, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get completed => $composableBuilder(
      column: $table.completed, builder: (column) => ColumnOrderings(column));

  $$CoursesTableOrderingComposer get courseId {
    final $$CoursesTableOrderingComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.courseId,
        referencedTable: $db.courses,
        getReferencedColumn: (t) => t.id,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$CoursesTableOrderingComposer(
              $db: $db,
              $table: $db.courses,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return composer;
  }

  $$TeeBoxTableTableOrderingComposer get teeBoxId {
    final $$TeeBoxTableTableOrderingComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.teeBoxId,
        referencedTable: $db.teeBoxTable,
        getReferencedColumn: (t) => t.id,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$TeeBoxTableTableOrderingComposer(
              $db: $db,
              $table: $db.teeBoxTable,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return composer;
  }
}

class $$RoundsTableAnnotationComposer
    extends Composer<_$AppDatabase, $RoundsTable> {
  $$RoundsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<DateTime> get date =>
      $composableBuilder(column: $table.date, builder: (column) => column);

  GeneratedColumn<String> get weather =>
      $composableBuilder(column: $table.weather, builder: (column) => column);

  GeneratedColumn<String> get notes =>
      $composableBuilder(column: $table.notes, builder: (column) => column);

  GeneratedColumn<bool> get completed =>
      $composableBuilder(column: $table.completed, builder: (column) => column);

  $$CoursesTableAnnotationComposer get courseId {
    final $$CoursesTableAnnotationComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.courseId,
        referencedTable: $db.courses,
        getReferencedColumn: (t) => t.id,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$CoursesTableAnnotationComposer(
              $db: $db,
              $table: $db.courses,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return composer;
  }

  $$TeeBoxTableTableAnnotationComposer get teeBoxId {
    final $$TeeBoxTableTableAnnotationComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.teeBoxId,
        referencedTable: $db.teeBoxTable,
        getReferencedColumn: (t) => t.id,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$TeeBoxTableTableAnnotationComposer(
              $db: $db,
              $table: $db.teeBoxTable,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return composer;
  }

  Expression<T> holesRefs<T extends Object>(
      Expression<T> Function($$HolesTableAnnotationComposer a) f) {
    final $$HolesTableAnnotationComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.id,
        referencedTable: $db.holes,
        getReferencedColumn: (t) => t.roundId,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$HolesTableAnnotationComposer(
              $db: $db,
              $table: $db.holes,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return f(composer);
  }
}

class $$RoundsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $RoundsTable,
    Round,
    $$RoundsTableFilterComposer,
    $$RoundsTableOrderingComposer,
    $$RoundsTableAnnotationComposer,
    $$RoundsTableCreateCompanionBuilder,
    $$RoundsTableUpdateCompanionBuilder,
    (Round, $$RoundsTableReferences),
    Round,
    PrefetchHooks Function({bool courseId, bool teeBoxId, bool holesRefs})> {
  $$RoundsTableTableManager(_$AppDatabase db, $RoundsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$RoundsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$RoundsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$RoundsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<int> id = const Value.absent(),
            Value<int> courseId = const Value.absent(),
            Value<int> teeBoxId = const Value.absent(),
            Value<DateTime> date = const Value.absent(),
            Value<String?> weather = const Value.absent(),
            Value<String?> notes = const Value.absent(),
            Value<bool> completed = const Value.absent(),
          }) =>
              RoundsCompanion(
            id: id,
            courseId: courseId,
            teeBoxId: teeBoxId,
            date: date,
            weather: weather,
            notes: notes,
            completed: completed,
          ),
          createCompanionCallback: ({
            Value<int> id = const Value.absent(),
            required int courseId,
            required int teeBoxId,
            Value<DateTime> date = const Value.absent(),
            Value<String?> weather = const Value.absent(),
            Value<String?> notes = const Value.absent(),
            Value<bool> completed = const Value.absent(),
          }) =>
              RoundsCompanion.insert(
            id: id,
            courseId: courseId,
            teeBoxId: teeBoxId,
            date: date,
            weather: weather,
            notes: notes,
            completed: completed,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) =>
                  (e.readTable(table), $$RoundsTableReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: (
              {courseId = false, teeBoxId = false, holesRefs = false}) {
            return PrefetchHooks(
              db: db,
              explicitlyWatchedTables: [if (holesRefs) db.holes],
              addJoins: <
                  T extends TableManagerState<
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic>>(state) {
                if (courseId) {
                  state = state.withJoin(
                    currentTable: table,
                    currentColumn: table.courseId,
                    referencedTable: $$RoundsTableReferences._courseIdTable(db),
                    referencedColumn:
                        $$RoundsTableReferences._courseIdTable(db).id,
                  ) as T;
                }
                if (teeBoxId) {
                  state = state.withJoin(
                    currentTable: table,
                    currentColumn: table.teeBoxId,
                    referencedTable: $$RoundsTableReferences._teeBoxIdTable(db),
                    referencedColumn:
                        $$RoundsTableReferences._teeBoxIdTable(db).id,
                  ) as T;
                }

                return state;
              },
              getPrefetchedDataCallback: (items) async {
                return [
                  if (holesRefs)
                    await $_getPrefetchedData<Round, $RoundsTable, Hole>(
                        currentTable: table,
                        referencedTable:
                            $$RoundsTableReferences._holesRefsTable(db),
                        managerFromTypedResult: (p0) =>
                            $$RoundsTableReferences(db, table, p0).holesRefs,
                        referencedItemsForCurrentItem: (item,
                                referencedItems) =>
                            referencedItems.where((e) => e.roundId == item.id),
                        typedResults: items)
                ];
              },
            );
          },
        ));
}

typedef $$RoundsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $RoundsTable,
    Round,
    $$RoundsTableFilterComposer,
    $$RoundsTableOrderingComposer,
    $$RoundsTableAnnotationComposer,
    $$RoundsTableCreateCompanionBuilder,
    $$RoundsTableUpdateCompanionBuilder,
    (Round, $$RoundsTableReferences),
    Round,
    PrefetchHooks Function({bool courseId, bool teeBoxId, bool holesRefs})>;
typedef $$CourseHolesTableCreateCompanionBuilder = CourseHolesCompanion
    Function({
  Value<int> id,
  required int courseId,
  required int holeNumber,
  required int par,
  Value<int?> strokeIndex,
});
typedef $$CourseHolesTableUpdateCompanionBuilder = CourseHolesCompanion
    Function({
  Value<int> id,
  Value<int> courseId,
  Value<int> holeNumber,
  Value<int> par,
  Value<int?> strokeIndex,
});

final class $$CourseHolesTableReferences
    extends BaseReferences<_$AppDatabase, $CourseHolesTable, CourseHole> {
  $$CourseHolesTableReferences(super.$_db, super.$_table, super.$_typedResult);

  static $CoursesTable _courseIdTable(_$AppDatabase db) =>
      db.courses.createAlias(
          $_aliasNameGenerator(db.courseHoles.courseId, db.courses.id));

  $$CoursesTableProcessedTableManager get courseId {
    final $_column = $_itemColumn<int>('course_id')!;

    final manager = $$CoursesTableTableManager($_db, $_db.courses)
        .filter((f) => f.id.sqlEquals($_column));
    final item = $_typedResult.readTableOrNull(_courseIdTable($_db));
    if (item == null) return manager;
    return ProcessedTableManager(
        manager.$state.copyWith(prefetchedData: [item]));
  }
}

class $$CourseHolesTableFilterComposer
    extends Composer<_$AppDatabase, $CourseHolesTable> {
  $$CourseHolesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get holeNumber => $composableBuilder(
      column: $table.holeNumber, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get par => $composableBuilder(
      column: $table.par, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get strokeIndex => $composableBuilder(
      column: $table.strokeIndex, builder: (column) => ColumnFilters(column));

  $$CoursesTableFilterComposer get courseId {
    final $$CoursesTableFilterComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.courseId,
        referencedTable: $db.courses,
        getReferencedColumn: (t) => t.id,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$CoursesTableFilterComposer(
              $db: $db,
              $table: $db.courses,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return composer;
  }
}

class $$CourseHolesTableOrderingComposer
    extends Composer<_$AppDatabase, $CourseHolesTable> {
  $$CourseHolesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get holeNumber => $composableBuilder(
      column: $table.holeNumber, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get par => $composableBuilder(
      column: $table.par, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get strokeIndex => $composableBuilder(
      column: $table.strokeIndex, builder: (column) => ColumnOrderings(column));

  $$CoursesTableOrderingComposer get courseId {
    final $$CoursesTableOrderingComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.courseId,
        referencedTable: $db.courses,
        getReferencedColumn: (t) => t.id,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$CoursesTableOrderingComposer(
              $db: $db,
              $table: $db.courses,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return composer;
  }
}

class $$CourseHolesTableAnnotationComposer
    extends Composer<_$AppDatabase, $CourseHolesTable> {
  $$CourseHolesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get holeNumber => $composableBuilder(
      column: $table.holeNumber, builder: (column) => column);

  GeneratedColumn<int> get par =>
      $composableBuilder(column: $table.par, builder: (column) => column);

  GeneratedColumn<int> get strokeIndex => $composableBuilder(
      column: $table.strokeIndex, builder: (column) => column);

  $$CoursesTableAnnotationComposer get courseId {
    final $$CoursesTableAnnotationComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.courseId,
        referencedTable: $db.courses,
        getReferencedColumn: (t) => t.id,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$CoursesTableAnnotationComposer(
              $db: $db,
              $table: $db.courses,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return composer;
  }
}

class $$CourseHolesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $CourseHolesTable,
    CourseHole,
    $$CourseHolesTableFilterComposer,
    $$CourseHolesTableOrderingComposer,
    $$CourseHolesTableAnnotationComposer,
    $$CourseHolesTableCreateCompanionBuilder,
    $$CourseHolesTableUpdateCompanionBuilder,
    (CourseHole, $$CourseHolesTableReferences),
    CourseHole,
    PrefetchHooks Function({bool courseId})> {
  $$CourseHolesTableTableManager(_$AppDatabase db, $CourseHolesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$CourseHolesTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$CourseHolesTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$CourseHolesTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<int> id = const Value.absent(),
            Value<int> courseId = const Value.absent(),
            Value<int> holeNumber = const Value.absent(),
            Value<int> par = const Value.absent(),
            Value<int?> strokeIndex = const Value.absent(),
          }) =>
              CourseHolesCompanion(
            id: id,
            courseId: courseId,
            holeNumber: holeNumber,
            par: par,
            strokeIndex: strokeIndex,
          ),
          createCompanionCallback: ({
            Value<int> id = const Value.absent(),
            required int courseId,
            required int holeNumber,
            required int par,
            Value<int?> strokeIndex = const Value.absent(),
          }) =>
              CourseHolesCompanion.insert(
            id: id,
            courseId: courseId,
            holeNumber: holeNumber,
            par: par,
            strokeIndex: strokeIndex,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (
                    e.readTable(table),
                    $$CourseHolesTableReferences(db, table, e)
                  ))
              .toList(),
          prefetchHooksCallback: ({courseId = false}) {
            return PrefetchHooks(
              db: db,
              explicitlyWatchedTables: [],
              addJoins: <
                  T extends TableManagerState<
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic>>(state) {
                if (courseId) {
                  state = state.withJoin(
                    currentTable: table,
                    currentColumn: table.courseId,
                    referencedTable:
                        $$CourseHolesTableReferences._courseIdTable(db),
                    referencedColumn:
                        $$CourseHolesTableReferences._courseIdTable(db).id,
                  ) as T;
                }

                return state;
              },
              getPrefetchedDataCallback: (items) async {
                return [];
              },
            );
          },
        ));
}

typedef $$CourseHolesTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $CourseHolesTable,
    CourseHole,
    $$CourseHolesTableFilterComposer,
    $$CourseHolesTableOrderingComposer,
    $$CourseHolesTableAnnotationComposer,
    $$CourseHolesTableCreateCompanionBuilder,
    $$CourseHolesTableUpdateCompanionBuilder,
    (CourseHole, $$CourseHolesTableReferences),
    CourseHole,
    PrefetchHooks Function({bool courseId})>;
typedef $$TeeBoxHolesTableCreateCompanionBuilder = TeeBoxHolesCompanion
    Function({
  Value<int> id,
  required int teeBoxId,
  required int holeNumber,
  Value<int?> yardage,
});
typedef $$TeeBoxHolesTableUpdateCompanionBuilder = TeeBoxHolesCompanion
    Function({
  Value<int> id,
  Value<int> teeBoxId,
  Value<int> holeNumber,
  Value<int?> yardage,
});

final class $$TeeBoxHolesTableReferences
    extends BaseReferences<_$AppDatabase, $TeeBoxHolesTable, TeeBoxHole> {
  $$TeeBoxHolesTableReferences(super.$_db, super.$_table, super.$_typedResult);

  static $TeeBoxTableTable _teeBoxIdTable(_$AppDatabase db) =>
      db.teeBoxTable.createAlias(
          $_aliasNameGenerator(db.teeBoxHoles.teeBoxId, db.teeBoxTable.id));

  $$TeeBoxTableTableProcessedTableManager get teeBoxId {
    final $_column = $_itemColumn<int>('tee_box_id')!;

    final manager = $$TeeBoxTableTableTableManager($_db, $_db.teeBoxTable)
        .filter((f) => f.id.sqlEquals($_column));
    final item = $_typedResult.readTableOrNull(_teeBoxIdTable($_db));
    if (item == null) return manager;
    return ProcessedTableManager(
        manager.$state.copyWith(prefetchedData: [item]));
  }
}

class $$TeeBoxHolesTableFilterComposer
    extends Composer<_$AppDatabase, $TeeBoxHolesTable> {
  $$TeeBoxHolesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get holeNumber => $composableBuilder(
      column: $table.holeNumber, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get yardage => $composableBuilder(
      column: $table.yardage, builder: (column) => ColumnFilters(column));

  $$TeeBoxTableTableFilterComposer get teeBoxId {
    final $$TeeBoxTableTableFilterComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.teeBoxId,
        referencedTable: $db.teeBoxTable,
        getReferencedColumn: (t) => t.id,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$TeeBoxTableTableFilterComposer(
              $db: $db,
              $table: $db.teeBoxTable,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return composer;
  }
}

class $$TeeBoxHolesTableOrderingComposer
    extends Composer<_$AppDatabase, $TeeBoxHolesTable> {
  $$TeeBoxHolesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get holeNumber => $composableBuilder(
      column: $table.holeNumber, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get yardage => $composableBuilder(
      column: $table.yardage, builder: (column) => ColumnOrderings(column));

  $$TeeBoxTableTableOrderingComposer get teeBoxId {
    final $$TeeBoxTableTableOrderingComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.teeBoxId,
        referencedTable: $db.teeBoxTable,
        getReferencedColumn: (t) => t.id,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$TeeBoxTableTableOrderingComposer(
              $db: $db,
              $table: $db.teeBoxTable,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return composer;
  }
}

class $$TeeBoxHolesTableAnnotationComposer
    extends Composer<_$AppDatabase, $TeeBoxHolesTable> {
  $$TeeBoxHolesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get holeNumber => $composableBuilder(
      column: $table.holeNumber, builder: (column) => column);

  GeneratedColumn<int> get yardage =>
      $composableBuilder(column: $table.yardage, builder: (column) => column);

  $$TeeBoxTableTableAnnotationComposer get teeBoxId {
    final $$TeeBoxTableTableAnnotationComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.teeBoxId,
        referencedTable: $db.teeBoxTable,
        getReferencedColumn: (t) => t.id,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$TeeBoxTableTableAnnotationComposer(
              $db: $db,
              $table: $db.teeBoxTable,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return composer;
  }
}

class $$TeeBoxHolesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $TeeBoxHolesTable,
    TeeBoxHole,
    $$TeeBoxHolesTableFilterComposer,
    $$TeeBoxHolesTableOrderingComposer,
    $$TeeBoxHolesTableAnnotationComposer,
    $$TeeBoxHolesTableCreateCompanionBuilder,
    $$TeeBoxHolesTableUpdateCompanionBuilder,
    (TeeBoxHole, $$TeeBoxHolesTableReferences),
    TeeBoxHole,
    PrefetchHooks Function({bool teeBoxId})> {
  $$TeeBoxHolesTableTableManager(_$AppDatabase db, $TeeBoxHolesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$TeeBoxHolesTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$TeeBoxHolesTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$TeeBoxHolesTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<int> id = const Value.absent(),
            Value<int> teeBoxId = const Value.absent(),
            Value<int> holeNumber = const Value.absent(),
            Value<int?> yardage = const Value.absent(),
          }) =>
              TeeBoxHolesCompanion(
            id: id,
            teeBoxId: teeBoxId,
            holeNumber: holeNumber,
            yardage: yardage,
          ),
          createCompanionCallback: ({
            Value<int> id = const Value.absent(),
            required int teeBoxId,
            required int holeNumber,
            Value<int?> yardage = const Value.absent(),
          }) =>
              TeeBoxHolesCompanion.insert(
            id: id,
            teeBoxId: teeBoxId,
            holeNumber: holeNumber,
            yardage: yardage,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (
                    e.readTable(table),
                    $$TeeBoxHolesTableReferences(db, table, e)
                  ))
              .toList(),
          prefetchHooksCallback: ({teeBoxId = false}) {
            return PrefetchHooks(
              db: db,
              explicitlyWatchedTables: [],
              addJoins: <
                  T extends TableManagerState<
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic>>(state) {
                if (teeBoxId) {
                  state = state.withJoin(
                    currentTable: table,
                    currentColumn: table.teeBoxId,
                    referencedTable:
                        $$TeeBoxHolesTableReferences._teeBoxIdTable(db),
                    referencedColumn:
                        $$TeeBoxHolesTableReferences._teeBoxIdTable(db).id,
                  ) as T;
                }

                return state;
              },
              getPrefetchedDataCallback: (items) async {
                return [];
              },
            );
          },
        ));
}

typedef $$TeeBoxHolesTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $TeeBoxHolesTable,
    TeeBoxHole,
    $$TeeBoxHolesTableFilterComposer,
    $$TeeBoxHolesTableOrderingComposer,
    $$TeeBoxHolesTableAnnotationComposer,
    $$TeeBoxHolesTableCreateCompanionBuilder,
    $$TeeBoxHolesTableUpdateCompanionBuilder,
    (TeeBoxHole, $$TeeBoxHolesTableReferences),
    TeeBoxHole,
    PrefetchHooks Function({bool teeBoxId})>;
typedef $$HolesTableCreateCompanionBuilder = HolesCompanion Function({
  Value<int> id,
  required int roundId,
  required int holeNumber,
  Value<int?> score,
  Value<int?> putts,
  Value<int?> penalties,
  Value<String?> fir,
  Value<String?> approachLocation,
  Value<int?> approachDistance,
  Value<int?> firstPuttDistance,
});
typedef $$HolesTableUpdateCompanionBuilder = HolesCompanion Function({
  Value<int> id,
  Value<int> roundId,
  Value<int> holeNumber,
  Value<int?> score,
  Value<int?> putts,
  Value<int?> penalties,
  Value<String?> fir,
  Value<String?> approachLocation,
  Value<int?> approachDistance,
  Value<int?> firstPuttDistance,
});

final class $$HolesTableReferences
    extends BaseReferences<_$AppDatabase, $HolesTable, Hole> {
  $$HolesTableReferences(super.$_db, super.$_table, super.$_typedResult);

  static $RoundsTable _roundIdTable(_$AppDatabase db) => db.rounds
      .createAlias($_aliasNameGenerator(db.holes.roundId, db.rounds.id));

  $$RoundsTableProcessedTableManager get roundId {
    final $_column = $_itemColumn<int>('round_id')!;

    final manager = $$RoundsTableTableManager($_db, $_db.rounds)
        .filter((f) => f.id.sqlEquals($_column));
    final item = $_typedResult.readTableOrNull(_roundIdTable($_db));
    if (item == null) return manager;
    return ProcessedTableManager(
        manager.$state.copyWith(prefetchedData: [item]));
  }
}

class $$HolesTableFilterComposer extends Composer<_$AppDatabase, $HolesTable> {
  $$HolesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get holeNumber => $composableBuilder(
      column: $table.holeNumber, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get score => $composableBuilder(
      column: $table.score, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get putts => $composableBuilder(
      column: $table.putts, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get penalties => $composableBuilder(
      column: $table.penalties, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get fir => $composableBuilder(
      column: $table.fir, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get approachLocation => $composableBuilder(
      column: $table.approachLocation,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get approachDistance => $composableBuilder(
      column: $table.approachDistance,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get firstPuttDistance => $composableBuilder(
      column: $table.firstPuttDistance,
      builder: (column) => ColumnFilters(column));

  $$RoundsTableFilterComposer get roundId {
    final $$RoundsTableFilterComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.roundId,
        referencedTable: $db.rounds,
        getReferencedColumn: (t) => t.id,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$RoundsTableFilterComposer(
              $db: $db,
              $table: $db.rounds,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return composer;
  }
}

class $$HolesTableOrderingComposer
    extends Composer<_$AppDatabase, $HolesTable> {
  $$HolesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get holeNumber => $composableBuilder(
      column: $table.holeNumber, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get score => $composableBuilder(
      column: $table.score, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get putts => $composableBuilder(
      column: $table.putts, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get penalties => $composableBuilder(
      column: $table.penalties, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get fir => $composableBuilder(
      column: $table.fir, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get approachLocation => $composableBuilder(
      column: $table.approachLocation,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get approachDistance => $composableBuilder(
      column: $table.approachDistance,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get firstPuttDistance => $composableBuilder(
      column: $table.firstPuttDistance,
      builder: (column) => ColumnOrderings(column));

  $$RoundsTableOrderingComposer get roundId {
    final $$RoundsTableOrderingComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.roundId,
        referencedTable: $db.rounds,
        getReferencedColumn: (t) => t.id,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$RoundsTableOrderingComposer(
              $db: $db,
              $table: $db.rounds,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return composer;
  }
}

class $$HolesTableAnnotationComposer
    extends Composer<_$AppDatabase, $HolesTable> {
  $$HolesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get holeNumber => $composableBuilder(
      column: $table.holeNumber, builder: (column) => column);

  GeneratedColumn<int> get score =>
      $composableBuilder(column: $table.score, builder: (column) => column);

  GeneratedColumn<int> get putts =>
      $composableBuilder(column: $table.putts, builder: (column) => column);

  GeneratedColumn<int> get penalties =>
      $composableBuilder(column: $table.penalties, builder: (column) => column);

  GeneratedColumn<String> get fir =>
      $composableBuilder(column: $table.fir, builder: (column) => column);

  GeneratedColumn<String> get approachLocation => $composableBuilder(
      column: $table.approachLocation, builder: (column) => column);

  GeneratedColumn<int> get approachDistance => $composableBuilder(
      column: $table.approachDistance, builder: (column) => column);

  GeneratedColumn<int> get firstPuttDistance => $composableBuilder(
      column: $table.firstPuttDistance, builder: (column) => column);

  $$RoundsTableAnnotationComposer get roundId {
    final $$RoundsTableAnnotationComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.roundId,
        referencedTable: $db.rounds,
        getReferencedColumn: (t) => t.id,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$RoundsTableAnnotationComposer(
              $db: $db,
              $table: $db.rounds,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return composer;
  }
}

class $$HolesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $HolesTable,
    Hole,
    $$HolesTableFilterComposer,
    $$HolesTableOrderingComposer,
    $$HolesTableAnnotationComposer,
    $$HolesTableCreateCompanionBuilder,
    $$HolesTableUpdateCompanionBuilder,
    (Hole, $$HolesTableReferences),
    Hole,
    PrefetchHooks Function({bool roundId})> {
  $$HolesTableTableManager(_$AppDatabase db, $HolesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$HolesTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$HolesTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$HolesTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<int> id = const Value.absent(),
            Value<int> roundId = const Value.absent(),
            Value<int> holeNumber = const Value.absent(),
            Value<int?> score = const Value.absent(),
            Value<int?> putts = const Value.absent(),
            Value<int?> penalties = const Value.absent(),
            Value<String?> fir = const Value.absent(),
            Value<String?> approachLocation = const Value.absent(),
            Value<int?> approachDistance = const Value.absent(),
            Value<int?> firstPuttDistance = const Value.absent(),
          }) =>
              HolesCompanion(
            id: id,
            roundId: roundId,
            holeNumber: holeNumber,
            score: score,
            putts: putts,
            penalties: penalties,
            fir: fir,
            approachLocation: approachLocation,
            approachDistance: approachDistance,
            firstPuttDistance: firstPuttDistance,
          ),
          createCompanionCallback: ({
            Value<int> id = const Value.absent(),
            required int roundId,
            required int holeNumber,
            Value<int?> score = const Value.absent(),
            Value<int?> putts = const Value.absent(),
            Value<int?> penalties = const Value.absent(),
            Value<String?> fir = const Value.absent(),
            Value<String?> approachLocation = const Value.absent(),
            Value<int?> approachDistance = const Value.absent(),
            Value<int?> firstPuttDistance = const Value.absent(),
          }) =>
              HolesCompanion.insert(
            id: id,
            roundId: roundId,
            holeNumber: holeNumber,
            score: score,
            putts: putts,
            penalties: penalties,
            fir: fir,
            approachLocation: approachLocation,
            approachDistance: approachDistance,
            firstPuttDistance: firstPuttDistance,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) =>
                  (e.readTable(table), $$HolesTableReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: ({roundId = false}) {
            return PrefetchHooks(
              db: db,
              explicitlyWatchedTables: [],
              addJoins: <
                  T extends TableManagerState<
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic>>(state) {
                if (roundId) {
                  state = state.withJoin(
                    currentTable: table,
                    currentColumn: table.roundId,
                    referencedTable: $$HolesTableReferences._roundIdTable(db),
                    referencedColumn:
                        $$HolesTableReferences._roundIdTable(db).id,
                  ) as T;
                }

                return state;
              },
              getPrefetchedDataCallback: (items) async {
                return [];
              },
            );
          },
        ));
}

typedef $$HolesTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $HolesTable,
    Hole,
    $$HolesTableFilterComposer,
    $$HolesTableOrderingComposer,
    $$HolesTableAnnotationComposer,
    $$HolesTableCreateCompanionBuilder,
    $$HolesTableUpdateCompanionBuilder,
    (Hole, $$HolesTableReferences),
    Hole,
    PrefetchHooks Function({bool roundId})>;

class $AppDatabaseManager {
  final _$AppDatabase _db;
  $AppDatabaseManager(this._db);
  $$CoursesTableTableManager get courses =>
      $$CoursesTableTableManager(_db, _db.courses);
  $$TeeBoxTableTableTableManager get teeBoxTable =>
      $$TeeBoxTableTableTableManager(_db, _db.teeBoxTable);
  $$RoundsTableTableManager get rounds =>
      $$RoundsTableTableManager(_db, _db.rounds);
  $$CourseHolesTableTableManager get courseHoles =>
      $$CourseHolesTableTableManager(_db, _db.courseHoles);
  $$TeeBoxHolesTableTableManager get teeBoxHoles =>
      $$TeeBoxHolesTableTableManager(_db, _db.teeBoxHoles);
  $$HolesTableTableManager get holes =>
      $$HolesTableTableManager(_db, _db.holes);
}
