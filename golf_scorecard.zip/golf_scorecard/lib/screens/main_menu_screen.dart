import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../providers/database_provider.dart';
import 'course_list_screen.dart';
import 'dashboard_screen.dart';
import 'hole_entry_screen.dart';
import 'saved_rounds_screen.dart';
import 'start_round_screen.dart';

class MainMenuScreen extends ConsumerWidget {
  const MainMenuScreen({super.key});

  String _fmtDate(DateTime dt) {
    final d = dt.toLocal();
    String two(int n) => n.toString().padLeft(2, '0');
    return '${two(d.month)}/${two(d.day)}/${d.year}';
  }

  /// Bulletproof preview line under "Resume Round".
  /// - null => no pill displayed
  /// - "Multiple in-progress rounds" => gray pill, not tappable
  /// - otherwise => green pill, tappable (resumes)
  Future<String?> _resumePreviewText(WidgetRef ref) async {
    final db = ref.read(databaseProvider);

    final active = await db.getInProgressRounds();
    if (active.isEmpty) return null;
    if (active.length > 1) return 'Multiple in-progress rounds';

    final round = active.first;

    // Courses / tees might be empty or might not contain referenced ids
    final courses = await db.getAllCourses();
    final tees = await db.select(db.teeBoxTable).get();

    final courseName = courses
            .where((c) => c.id == round.courseId)
            .map((c) => c.name)
            .cast<String?>()
            .firstWhere(
              (name) => name != null && name.trim().isNotEmpty,
              orElse: () => null,
            ) ??
        'Course ${round.courseId}';

    final teeName = tees
            .where((t) => t.id == round.teeBoxId)
            .map((t) => t.name)
            .cast<String?>()
            .firstWhere(
              (name) => name != null && name.trim().isNotEmpty,
              orElse: () => null,
            ) ??
        'Tee ${round.teeBoxId}';

    // Progress: ask the DB layer (no drift ordering in UI)
    final latestHoleNumber = await db.getLatestHoleNumberForRound(round.id);

    // Next hole logic
    String progressText;
    if (latestHoleNumber == null) {
      progressText = 'Next: Hole 1';
    } else if (latestHoleNumber >= 18) {
      progressText = 'At Hole 18';
    } else {
      progressText = 'Next: Hole ${latestHoleNumber + 1}';
    }

    final dateStr = _fmtDate(round.date);

    return 'Resumes: $courseName • $teeName • $dateStr • $progressText';
  }

  Future<int?> _pickDashboardRoundId({
    required BuildContext context,
    required WidgetRef ref,
  }) async {
    final db = ref.read(databaseProvider);

    final completed = await db.getCompletedRounds();
    if (completed.isEmpty) {
      if (!context.mounted) return null;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('No completed rounds yet. Finish a round first.'),
        ),
      );
      return null;
    }

    completed.sort((a, b) => b.date.compareTo(a.date));
    final courses = await db.getAllCourses();
    final tees = await db.select(db.teeBoxTable).get();

    final courseById = {for (final c in courses) c.id: c};
    final teeById = {for (final t in tees) t.id: t};

    if (!context.mounted) return null;

    return showDialog<int>(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          title: const Text('Pick a round for Dashboard'),
          content: SizedBox(
            width: double.maxFinite,
            child: ListView.separated(
              shrinkWrap: true,
              itemCount: completed.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (_, i) {
                final r = completed[i];
                final courseName =
                    courseById[r.courseId]?.name ?? 'Unknown course';
                final teeName = teeById[r.teeBoxId]?.name ?? 'Unknown tee';
                final dateStr = _fmtDate(r.date);

                return ListTile(
                  title: Text(courseName),
                  subtitle: Text('$teeName • $dateStr'),
                  onTap: () => Navigator.pop(ctx, r.id),
                );
              },
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, null),
              child: const Text('Cancel'),
            ),
          ],
        );
      },
    );
  }

  Future<int?> _pickInProgressRoundId({
    required BuildContext context,
    required WidgetRef ref,
  }) async {
    final db = ref.read(databaseProvider);

    final active = await db.getInProgressRounds();
    if (active.isEmpty) return null;

    // If only one, return it directly
    if (active.length == 1) return active.first.id;

    // Otherwise show a picker
    final courses = await db.getAllCourses();
    final tees = await db.select(db.teeBoxTable).get();

    final courseById = {for (final c in courses) c.id: c};
    final teeById = {for (final t in tees) t.id: t};

    if (!context.mounted) return null;

    return showDialog<int>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Resume which round?'),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView.separated(
            shrinkWrap: true,
            itemCount: active.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (_, i) {
              final r = active[i];
              final courseName =
                  courseById[r.courseId]?.name ?? 'Unknown course';
              final teeName = teeById[r.teeBoxId]?.name ?? 'Unknown tee';
              final dateStr = _fmtDate(r.date);

              return ListTile(
                title: Text(courseName),
                subtitle: Text('$teeName • $dateStr'),
                onTap: () => Navigator.pop(ctx, r.id),
              );
            },
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, null),
            child: const Text('Cancel'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final db = ref.read(databaseProvider);

    Future<void> resumeRound() async {
      final active = await db.getInProgressRounds();

      if (active.isEmpty) {
        if (!context.mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('No in-progress round found.')),
        );
        return;
      }

      if (active.length == 1) {
        if (!context.mounted) return;
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => HoleEntryScreen(roundId: active.first.id),
          ),
        );
        return;
      }

      final pickedId = await _pickInProgressRoundId(context: context, ref: ref);
      if (pickedId == null) return;

      if (!context.mounted) return;
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => HoleEntryScreen(roundId: pickedId)),
      );
    }

    Future<void> openDashboardWithPicker() async {
      final roundId = await _pickDashboardRoundId(context: context, ref: ref);
      if (roundId == null) return;

      if (!context.mounted) return;
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => DashboardScreen(roundId: roundId)),
      );
    }

    // ✅ With "enforce one active round", StartRoundScreen handles the rule.
    void openStartRound() {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const StartRoundScreen()),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Golf Scorecard')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: openStartRound,
                child: const Text('Start Round'),
              ),
            ),
            const SizedBox(height: 12),

            SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                onPressed: resumeRound,
                child: const Text('Resume Round'),
              ),
            ),

            // ✅ Green/gray tappable pill preview
            FutureBuilder<String?>(
              future: _resumePreviewText(ref),
              builder: (context, snap) {
                final text = snap.data;
                if (text == null || text.trim().isEmpty) {
                  return const SizedBox(height: 8);
                }

                final isMultiple =
                    text.toLowerCase().contains('multiple in-progress');

                final pillColor =
                    isMultiple ? Colors.grey[200] : Colors.green[100];
                final borderColor =
                    isMultiple ? Colors.grey[350] : Colors.green[400];
                final iconColor =
                    isMultiple ? Colors.grey[700] : Colors.green[800];
                final textColor =
                    isMultiple ? Colors.grey[800] : Colors.green[900];

                return Padding(
                  padding: const EdgeInsets.only(top: 6, bottom: 12),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: InkWell(
                      onTap: isMultiple ? null : resumeRound,
                      borderRadius: BorderRadius.circular(999),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 14,
                          vertical: 10,
                        ),
                        decoration: BoxDecoration(
                          color: pillColor,
                          borderRadius: BorderRadius.circular(999),
                          border: Border.all(color: borderColor!),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              isMultiple
                                  ? Icons.info_outline
                                  : Icons.play_arrow,
                              size: 18,
                              color: iconColor,
                            ),
                            const SizedBox(width: 8),
                            Flexible(
                              child: Text(
                                text,
                                style: TextStyle(
                                  color: textColor,
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),

            const SizedBox(height: 2),

            SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const SavedRoundsScreen(),
                    ),
                  );
                },
                child: const Text('Saved Rounds'),
              ),
            ),
            const SizedBox(height: 12),

            SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const CourseListScreen(),
                    ),
                  );
                },
                child: const Text('Courses'),
              ),
            ),
            const SizedBox(height: 12),

            SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                onPressed: openDashboardWithPicker,
                child: const Text('Dashboard'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
