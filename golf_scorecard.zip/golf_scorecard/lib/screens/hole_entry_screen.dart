import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../db/app_database.dart';
import '../providers/database_provider.dart';
import 'round_summary_screen.dart';

class HoleEntryScreen extends ConsumerStatefulWidget {
  final int roundId;

  /// Optional: open the screen on a specific hole (1-18).
  final int initialHole;

  const HoleEntryScreen({
    super.key,
    required this.roundId,
    this.initialHole = 1,
  });

  @override
  ConsumerState<HoleEntryScreen> createState() => _HoleEntryScreenState();
}

class _HoleEntryScreenState extends ConsumerState<HoleEntryScreen> {
  int _holeNumber = 1;

  int? _score; // 1..10
  int? _putts; // 0..4
  int? _penalties; // 0..2

  String? _fir; // "L" | "C" | "R"
  String? _approachLocation; // "L" | "C" | "R" | "LONG" | "SHORT"

  int? _approachDistance; // 0..175
  int? _firstPuttDistance; // 0..60

  bool _loading = true;
  bool _busy = false;

  Timer? _autoSaveTimer;

  Round? _round;
  final Map<int, CourseHole> _courseHoleByNum = {};
  final Map<int, TeeBoxHole> _teeHoleByNum = {};

  @override
  void initState() {
    super.initState();
    _holeNumber = widget.initialHole.clamp(1, 18);
    _init();
  }

  @override
  void dispose() {
    _autoSaveTimer?.cancel();
    super.dispose();
  }

  Future<void> _init() async {
    final db = ref.read(databaseProvider);

    final r = await db.getRound(widget.roundId);
    _round = r;

    if (r != null) {
      final ch = await db.getCourseHolesForCourse(r.courseId);
      _courseHoleByNum
        ..clear()
        ..addEntries(ch.map((h) => MapEntry(h.holeNumber, h)));

      final th = await db.getTeeBoxHoles(r.teeBoxId);
      _teeHoleByNum
        ..clear()
        ..addEntries(th.map((h) => MapEntry(h.holeNumber, h)));
    }

    await _loadHole(_holeNumber);
  }

  // ---------------- Autosave (debounced) ----------------

  void _scheduleAutoSave() {
    // Don’t autosave while loading or during a navigation save/load.
    if (_loading || _busy) return;

    _autoSaveTimer?.cancel();
    _autoSaveTimer = Timer(const Duration(milliseconds: 450), () async {
      if (!mounted) return;
      if (_busy || _loading) return;
      await _saveCurrentHole();
    });
  }

  void _cancelAutoSave() => _autoSaveTimer?.cancel();

  // ---------------- Navigation (buttons + swipe) ----------------

  Future<void> _onSwipe(DragEndDetails details) async {
    final velocity = details.primaryVelocity ?? 0;

    // Right swipe (positive) => Back
    if (velocity > 350) {
      await _goBack();
    }

    // Left swipe (negative) => Next
    if (velocity < -350) {
      await _goNext();
    }
  }

  Future<void> _goBack() async {
    if (_holeNumber <= 1) return;
    if (_loading || _busy) return;

    _cancelAutoSave();

    final target = _holeNumber - 1;

    final ok = await _saveCurrentHole();
    if (!ok) return;

    await _loadHole(target);
  }

  Future<void> _goNext() async {
    if (_loading || _busy) return;

    // Require score before moving forward (keeps on-course flow sane)
    if (_score == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Pick a score before moving on.')),
      );
      return;
    }

    _cancelAutoSave();

    final isLastHole = _holeNumber == 18;
    final target = _holeNumber + 1;

    final ok = await _saveCurrentHole();
    if (!ok) return;

    if (isLastHole) {
      await _finishRound();
      return;
    }

    await _loadHole(target);
  }

  Future<void> _finishRound() async {
    if (_loading || _busy) return;

    _cancelAutoSave();

    final ok = await _saveCurrentHole();
    if (!ok) return;

    final db = ref.read(databaseProvider);
    await db.setRoundCompleted(widget.roundId, true);

    if (!mounted) return;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => RoundSummaryScreen(roundId: widget.roundId),
      ),
    );
  }

  // ---------------- Load/Save ----------------

  Future<void> _loadHole(int holeNumber) async {
    if (_busy) return;
    _busy = true;

    var didSetLoadingTrue = false;

    try {
      if (mounted) {
        didSetLoadingTrue = true;
        setState(() => _loading = true);
      }

      final db = ref.read(databaseProvider);
      final hole = await db.getHole(widget.roundId, holeNumber);

      if (!mounted) return;

      setState(() {
        _holeNumber = holeNumber;

        _score = hole?.score;
        _putts = hole?.putts;
        _penalties = hole?.penalties;

        _fir = hole?.fir;
        _approachLocation = hole?.approachLocation;

        _approachDistance = hole?.approachDistance;
        _firstPuttDistance = hole?.firstPuttDistance;

        _loading = false;
      });
    } finally {
      _busy = false;
      if (mounted && didSetLoadingTrue && _loading) {
        setState(() => _loading = false);
      }
    }
  }

  bool get _hasAnythingToSave {
    return _score != null ||
        _putts != null ||
        _penalties != null ||
        _fir != null ||
        _approachLocation != null ||
        _approachDistance != null ||
        _firstPuttDistance != null;
  }

  Future<bool> _saveCurrentHole() async {
    if (_busy) return false;

    // Don’t create an empty record
    if (!_hasAnythingToSave) return true;

    _busy = true;

    try {
      final db = ref.read(databaseProvider);

      await db.upsertHole(
        roundId: widget.roundId,
        holeNumber: _holeNumber,
        score: _score,
        putts: _putts,
        penalties: _penalties,
        fir: _fir,
        approachLocation: _approachLocation,
        approachDistance: _approachDistance,
        firstPuttDistance: _firstPuttDistance,
      );

      return true;
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Save failed: $e')),
        );
      }
      return false;
    } finally {
      _busy = false;
    }
  }

  // ---------------- Computed fields ----------------

  int? get _par => _courseHoleByNum[_holeNumber]?.par;
  int? get _yardage => _teeHoleByNum[_holeNumber]?.yardage;

  bool? get _gir {
    final par = _par;
    final score = _score;
    final putts = _putts;
    if (par == null || score == null || putts == null) return null;

    // GIR if strokes_to_green <= par - 2
    final strokesToGreen = score - putts;
    return strokesToGreen <= (par - 2);
  }

  bool? get _upAndDown {
    final par = _par;
    final score = _score;
    final gir = _gir;
    if (par == null || score == null || gir == null) return null;

    // Up & down: missed GIR but made par or better
    return (gir == false) && (score <= par);
  }

  // ---------------- UI helpers ----------------

  Widget _sectionTitle(String text) => Padding(
        padding: const EdgeInsets.only(top: 16, bottom: 8),
        child: Text(
          text,
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
      );

  Widget _chipRow<T>({
    required List<T> values,
    required T? selected,
    required String Function(T v) label,
    required void Function(T v) onSelected,
    Color? Function(T v)? selectedColor,
  }) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: values.map((v) {
        final isSelected = selected == v;
        final selColor = selectedColor?.call(v);

        return ChoiceChip(
          label: Text(label(v)),
          selected: isSelected,
          selectedColor: selColor,
          onSelected: (_) => onSelected(v),
        );
      }).toList(),
    );
  }

  Widget _distanceSlider({
    required String label,
    required int max,
    required int? value,
    required void Function(int v) onChanged,
  }) {
    final v = value ?? 0;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('$label: $v'),
        Slider(
          value: v.toDouble(),
          min: 0,
          max: max.toDouble(),
          divisions: max,
          label: v.toString(),
          onChanged: (d) => setState(() {
            onChanged(d.round());
            _scheduleAutoSave();
          }),
        ),
      ],
    );
  }

  Color? _firSelectedColor(String code) {
    switch (code) {
      case 'C':
        return Colors.green;
      case 'L':
      case 'R':
        return Colors.yellow;
      default:
        return null;
    }
  }

  Color? _approachSelectedColor(String code) {
    switch (code) {
      case 'C':
        return Colors.green;
      case 'L':
      case 'R':
        return Colors.yellow;
      case 'LONG':
      case 'SHORT':
        return Colors.cyan;
      default:
        return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final isLastHole = _holeNumber == 18;

    final par = _par;
    final yds = _yardage;
    final gir = _gir;
    final upDown = _upAndDown;

    final buttonsDisabled = _loading || _busy;

    return Scaffold(
      appBar: AppBar(
        title: Text('Hole $_holeNumber'),
      ),
      body: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onHorizontalDragEnd: _onSwipe,
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  // Hole context row
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                              'Par: ${par ?? '-'}   Yardage: ${yds ?? '-'}',
                            ),
                          ),
                          const SizedBox(width: 8),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(
                                'GIR: ${gir == null ? '-' : (gir ? 'Yes' : 'No')}',
                              ),
                              Text(
                                'Up&Down: ${upDown == null ? '-' : (upDown ? 'Yes' : 'No')}',
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),

                  _sectionTitle('Score'),
                  _chipRow<int>(
                    values: List.generate(10, (i) => i + 1),
                    selected: _score,
                    label: (v) => v.toString(),
                    onSelected: (v) {
                      setState(() => _score = v);
                      _scheduleAutoSave();
                    },
                  ),

                  _sectionTitle('Putts'),
                  _chipRow<int>(
                    values: const [0, 1, 2, 3, 4],
                    selected: _putts,
                    label: (v) => v.toString(),
                    onSelected: (v) {
                      setState(() => _putts = v);
                      _scheduleAutoSave();
                    },
                  ),

                  _sectionTitle('Penalties'),
                  _chipRow<int>(
                    values: const [0, 1, 2],
                    selected: _penalties,
                    label: (v) => v.toString(),
                    onSelected: (v) {
                      setState(() => _penalties = v);
                      _scheduleAutoSave();
                    },
                  ),

                  _sectionTitle('FIR'),
                  _chipRow<String>(
                    values: const ['L', 'C', 'R'],
                    selected: _fir,
                    label: (v) => v == 'L'
                        ? 'Left'
                        : v == 'C'
                            ? 'Center'
                            : 'Right',
                    selectedColor: _firSelectedColor,
                    onSelected: (v) {
                      setState(() => _fir = v);
                      _scheduleAutoSave();
                    },
                  ),

                  _sectionTitle('Approach Location'),
                  _chipRow<String>(
                    values: const ['L', 'C', 'R', 'LONG', 'SHORT'],
                    selected: _approachLocation,
                    label: (v) {
                      switch (v) {
                        case 'L':
                          return 'Left';
                        case 'C':
                          return 'Center';
                        case 'R':
                          return 'Right';
                        case 'LONG':
                          return 'Long';
                        case 'SHORT':
                          return 'Short';
                        default:
                          return v;
                      }
                    },
                    selectedColor: _approachSelectedColor,
                    onSelected: (v) {
                      setState(() => _approachLocation = v);
                      _scheduleAutoSave();
                    },
                  ),

                  _sectionTitle('Approach Distance'),
                  _distanceSlider(
                    label: 'Approach (max 175)',
                    max: 175,
                    value: _approachDistance,
                    onChanged: (v) => _approachDistance = v,
                  ),

                  _sectionTitle('First Putt Distance'),
                  _distanceSlider(
                    label: 'First putt (max 60)',
                    max: 60,
                    value: _firstPuttDistance,
                    onChanged: (v) => _firstPuttDistance = v,
                  ),

                  const SizedBox(height: 24),

                  // Finish CTA on hole 18
                  if (isLastHole)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          onPressed: buttonsDisabled ? null : _finishRound,
                          icon: const Icon(Icons.flag),
                          label: const Text('Finish Round'),
                        ),
                      ),
                    ),

                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: (!buttonsDisabled && _holeNumber > 1)
                              ? _goBack
                              : null,
                          child: const Text('Back'),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton(
                          onPressed: buttonsDisabled
                              ? null
                              : (isLastHole ? _finishRound : _goNext),
                          child: Text(isLastHole ? 'Round Summary' : 'Next'),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 12),
                  Text(
                    'Tip: Swipe left/right to move holes (auto-saves).',
                    style: Theme.of(context)
                        .textTheme
                        .bodySmall
                        ?.copyWith(color: Colors.black54),
                  ),
                ],
              ),
      ),
    );
  }
}
