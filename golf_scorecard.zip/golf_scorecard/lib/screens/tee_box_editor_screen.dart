import 'package:flutter/material.dart';
import '../db/app_database.dart';

class TeeBoxEditorScreen extends StatefulWidget {
  final int courseId;
  const TeeBoxEditorScreen({super.key, required this.courseId});

  @override
  _TeeBoxEditorScreenState createState() => _TeeBoxEditorScreenState();
}

class _TeeBoxEditorScreenState extends State<TeeBoxEditorScreen> {
  List<TeeBox> teeBoxes = [];
  TeeBox? selectedTee;
  final TextEditingController teeNameController = TextEditingController();
  final TextEditingController yardageController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadTeeBoxes();
  }

  Future<void> _loadTeeBoxes() async {
    final db = AppDatabase();
    teeBoxes = await db.getTeeBoxesForCourse(widget.courseId);
    setState(() {});
  }

  Future<void> _addTeeBox() async {
    final db = AppDatabase();
    await db.createTeeBox(
      widget.courseId,
      teeNameController.text,
      int.tryParse(yardageController.text) ?? 0,
    );
    _loadTeeBoxes();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Tee Box Editor')),
      body: Column(
        children: [
          DropdownButton<TeeBox>(
            hint: const Text('Select Tee Box'),
            value: selectedTee,
            items: teeBoxes
                .map((t) => DropdownMenuItem(value: t, child: Text(t.name)))
                .toList(),
            onChanged: (val) {
              setState(() {
                selectedTee = val;
              });
            },
          ),
          TextField(
              controller: teeNameController,
              decoration: const InputDecoration(labelText: 'Tee Name')),
          TextField(
              controller: yardageController,
              decoration: const InputDecoration(labelText: 'Yardage')),
          ElevatedButton(
              onPressed: _addTeeBox, child: const Text('Add Tee Box')),
        ],
      ),
    );
  }
}
