import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../db/app_database.dart';
import '../providers/database_provider.dart';

class CourseHolesEditorScreen extends ConsumerStatefulWidget {
  final int courseId;
  const CourseHolesEditorScreen({super.key, required this.courseId});

  @override
  ConsumerState<CourseHolesEditorScreen> createState() =>
      _CourseHolesEditorScreenState();
}

class _CourseHolesEditorScreenState
    extends ConsumerState<CourseHolesEditorScreen> {
  bool _loading = true;

  List<CourseHole> _courseHoles = [];
  List<TeeBox> _teeBoxes = [];
  TeeBox? _selectedTee;
  List<TeeBoxHole> _teeHoles = [];

  // Par selections (1–18)
  final List<int> _pars = List.generate(18, (_) => 4);

  // Stroke Index values (nullable = unused)
  final List<int?> _strokeIndexes = List.generate(18, (_) => null);

  // Yardage values (nullable = unused)
  final List<int?> _yardages = List.generate(18, (_) => null);

  @override
  void initState() {
    super.initState();
    _loadAll();
  }

  Future<void> _loadAll() async {
    final db = ref.read(databaseProvider);

    final tees = await db.getTeeBoxesForCourse(widget.courseId);
    final ch = await db.getCourseHolesForCourse(widget.courseId);

    setState(() {
      _teeBoxes = tees;
      _selectedTee = tees.isNotEmpty ? tees.first : null;
      _courseHoles = ch;
    });

    _applyCourseHolesToUI();

    if (_selectedTee != null) {
      await _loadTeeHoles(_selectedTee!.id);
    } else {
      setState(() => _loading = false);
    }
  }

  void _applyCourseHolesToUI() {
    for (int i = 0; i < 18; i++) {
      final holeNum = i + 1;
      final existing =
          _courseHoles.where((h) => h.holeNumber == holeNum).toList();

      if (existing.isNotEmpty) {
        _pars[i] = existing.first.par;
        _strokeIndexes[i] = existing.first.strokeIndex;
      } else {
        _pars[i] = 4;
        _strokeIndexes[i] = null;
      }
    }
  }

  Future<void> _loadTeeHoles(int teeBoxId) async {
    setState(() {
      _loading = true;
      _teeHoles = [];
    });

    final db = ref.read(databaseProvider);
    final th = await db.getTeeBoxHoles(teeBoxId);

    setState(() {
      _teeHoles = th;
      _loading = false;
    });

    for (int i = 0; i < 18; i++) {
      final holeNum = i + 1;
      final existing = _teeHoles.where((h) => h.holeNumber == holeNum).toList();
      _yardages[i] = existing.isNotEmpty ? existing.first.yardage : null;
    }
  }

  Future<void> _saveAll() async {
    final db = ref.read(databaseProvider);

    // Save course holes (par + stroke index)
    for (int i = 0; i < 18; i++) {
      final holeNum = i + 1;
      final par = _pars[i];

      final si = _strokeIndexes[i];
      final validSi = (si == null) ? null : si.clamp(1, 18);

      await db.upsertCourseHole(
        courseId: widget.courseId,
        holeNumber: holeNum,
        par: par,
        strokeIndex: validSi,
      );
    }

    // Save yardages for selected tee
    final tee = _selectedTee;
    if (tee != null) {
      for (int i = 0; i < 18; i++) {
        final holeNum = i + 1;

        final yard = _yardages[i];
        final validYard = (yard == null) ? null : yard.clamp(0, 650);

        await db.upsertTeeBoxHole(
          teeBoxId: tee.id,
          holeNumber: holeNum,
          yardage: validYard,
        );
      }
    }

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Saved hole pars / SI / yardages')),
    );

    await _loadAll();
  }

  Widget _sectionTitle(String text) => Padding(
        padding: const EdgeInsets.only(top: 16, bottom: 8),
        child: Text(
          text,
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
      );

  Widget _parChips(int index) {
    return Wrap(
      spacing: 8,
      children: [3, 4, 5].map((p) {
        return ChoiceChip(
          label: Text('Par $p'),
          selected: _pars[index] == p,
          onSelected: (_) => setState(() => _pars[index] = p),
        );
      }).toList(),
    );
  }

  Widget _strokeIndexStepper(int index) {
    final value = _strokeIndexes[index];

    return Row(
      children: [
        const Text(
          'Stroke Index:',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        const SizedBox(width: 12),

        // Clear
        IconButton(
          tooltip: 'Clear',
          icon: const Icon(Icons.close),
          onPressed: () => setState(() => _strokeIndexes[index] = null),
        ),

        // Down
        IconButton(
          tooltip: 'Down',
          icon: const Icon(Icons.remove_circle_outline),
          onPressed: (value == null || value <= 1)
              ? null
              : () => setState(() => _strokeIndexes[index] = value - 1),
        ),

        // Value
        Container(
          width: 40,
          alignment: Alignment.center,
          child: Text(
            value?.toString() ?? '-',
            style: const TextStyle(fontSize: 16),
          ),
        ),

        // Up
        IconButton(
          tooltip: 'Up',
          icon: const Icon(Icons.add_circle_outline),
          onPressed: value == null
              ? () => setState(() => _strokeIndexes[index] = 1)
              : (value >= 18
                  ? null
                  : () => setState(() => _strokeIndexes[index] = value + 1)),
        ),
      ],
    );
  }

  Widget _yardageStepper(int index) {
    final value = _yardages[index];

    const int minYard = 0;
    const int maxYard = 650;

    void setVal(int? v) {
      if (v == null) {
        setState(() => _yardages[index] = null);
        return;
      }
      final clamped = v.clamp(minYard, maxYard);
      setState(() => _yardages[index] = clamped);
    }

    Widget stepBtn(String label, int delta) {
      final disabled = value == null
          ? (delta < 0)
          : (value + delta < minYard || value + delta > maxYard);

      return OutlinedButton(
        onPressed: disabled
            ? null
            : () {
                if (value == null) return;
                setVal(value + delta);
              },
        child: Text(label),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Text(
              'Yardage:',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(width: 12),

            IconButton(
              tooltip: 'Clear',
              icon: const Icon(Icons.close),
              onPressed: () => setVal(null),
            ),
            const SizedBox(width: 6),

            Container(
              width: 60,
              alignment: Alignment.center,
              padding: const EdgeInsets.symmetric(vertical: 6),
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                value?.toString() ?? '-',
                style: const TextStyle(fontSize: 16),
              ),
            ),

            const Spacer(),

            // If empty, quick-start a reasonable value
            TextButton(
              onPressed: value == null ? () => setVal(100) : null,
              child: const Text('Set'),
            ),
          ],
        ),
        const SizedBox(height: 6),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            stepBtn('-10', -10),
            stepBtn('-5', -5),
            OutlinedButton(
              onPressed: value == null ? null : () => setVal(value - 1),
              child: const Text('-1'),
            ),
            OutlinedButton(
              onPressed: value == null ? null : () => setVal(value + 1),
              child: const Text('+1'),
            ),
            stepBtn('+5', 5),
            stepBtn('+10', 10),
          ],
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit Holes'),
        actions: [
          IconButton(
            icon: const Icon(Icons.save),
            tooltip: 'Save',
            onPressed: _saveAll,
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                _sectionTitle('Course holes (Par + Stroke Index)'),
                for (int i = 0; i < 18; i++)
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Hole ${i + 1}',
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 8),

                          // Par chips
                          _parChips(i),

                          const SizedBox(height: 10),

                          // Stroke index stepper (1..18 or blank)
                          _strokeIndexStepper(i),
                        ],
                      ),
                    ),
                  ),
                const SizedBox(height: 18),
                _sectionTitle('Tee yardages (per hole)'),
                if (_teeBoxes.isEmpty)
                  const Text('No tee boxes yet. Add a tee box first.')
                else ...[
                  DropdownButtonFormField<TeeBox>(
                    value: _selectedTee,
                    decoration: const InputDecoration(
                      labelText: 'Tee Box',
                      border: OutlineInputBorder(),
                    ),
                    isExpanded: true,
                    items: _teeBoxes
                        .map((t) => DropdownMenuItem(
                              value: t,
                              child: Text(
                                '${t.name} • ${t.yardage} • ${t.rating} / ${t.slope}',
                              ),
                            ))
                        .toList(),
                    onChanged: (t) async {
                      if (t == null) return;
                      setState(() => _selectedTee = t);
                      await _loadTeeHoles(t.id);
                    },
                  ),
                  const SizedBox(height: 10),
                  for (int i = 0; i < 18; i++)
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Hole ${i + 1}',
                              style:
                                  const TextStyle(fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 8),
                            _yardageStepper(i),
                          ],
                        ),
                      ),
                    ),
                ],
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _saveAll,
                    child: const Text('Save All'),
                  ),
                ),
              ],
            ),
    );
  }
}
