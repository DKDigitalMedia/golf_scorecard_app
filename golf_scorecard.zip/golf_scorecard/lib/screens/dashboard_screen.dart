import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../db/app_database.dart';
import '../providers/database_provider.dart';
import 'round_summary_screen.dart';

class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final db = ref.read(databaseProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Dashboard')),
      body: FutureBuilder<_DashboardData>(
        future: _load(db),
        builder: (context, snap) {
          if (!snap.hasData) {
            if (snap.hasError) {
              return Center(child: Text('Error: ${snap.error}'));
            }
            return const Center(child: CircularProgressIndicator());
          }

          final data = snap.data!;
          if (data.rounds.isEmpty) {
            return const Center(
              child: Text(
                  'No completed rounds yet.\nFinish a round to see stats.'),
            );
          }

          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _StatsCard(data.stats),
              const SizedBox(height: 16),
              const Text(
                'Recent Rounds',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              ...data.rounds.map((r) {
                final courseName = data.courseNameById[r.courseId] ?? 'Course';
                final teeName = data.teeNameById[r.teeBoxId] ?? 'Tee';
                final total = data.totalScoreByRoundId[r.id] ?? 0;
                final par = data.totalParByRoundId[r.id] ?? 0;
                final toPar = total - par;

                String fmtToPar(int v) {
                  if (v == 0) return 'E';
                  return v > 0 ? '+$v' : '$v';
                }

                return Card(
                  child: ListTile(
                    title: Text('$courseName — $teeName'),
                    subtitle: Text('Score: $total (${fmtToPar(toPar)})'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => RoundSummaryScreen(roundId: r.id),
                        ),
                      );
                    },
                  ),
                );
              }),
            ],
          );
        },
      ),
    );
  }

  static Future<_DashboardData> _load(AppDatabase db) async {
    final rounds = await db.getCompletedRoundsNewestFirst();
    if (rounds.isEmpty) {
      return _DashboardData.empty();
    }

    // Load courses/tees names
    final courses = await db.getAllCourses();
    final courseNameById = {for (final c in courses) c.id: c.name};

    final tees = await db.getAllTeeBoxes();
    final teeNameById = {for (final t in tees) t.id: t.name};

    // For each round compute totals & stats
    int roundsCount = 0;
    int sumScore = 0;
    int sumPar = 0;

    int firOpps = 0;
    int firHits = 0;

    int girOpps = 0;
    int girHits = 0;

    int totalPutts = 0;
    int puttCountHoles = 0;

    int totalPenalties = 0;

    final totalScoreByRoundId = <int, int>{};
    final totalParByRoundId = <int, int>{};

    for (final r in rounds) {
      roundsCount++;

      final holes = await db.getHolesForRound(r.id);
      final courseHoles = await db.getCourseHolesForCourse(r.courseId);
      final parByHole = {for (final h in courseHoles) h.holeNumber: h.par};

      int roundScore = 0;
      int roundPar = 0;

      for (final h in holes) {
        final par = parByHole[h.holeNumber] ?? 0;
        roundPar += par;

        roundScore += (h.score ?? 0);

        // FIR opps: par 4/5
        if (par == 4 || par == 5) {
          firOpps++;
          if (h.fir == 'C') firHits++;
        }

        // GIR: requires score+putts+par
        if (par != 0 && h.score != null && h.putts != null) {
          girOpps++;
          final strokesToGreen = h.score! - h.putts!;
          if (strokesToGreen <= (par - 2)) girHits++;
        }

        if (h.putts != null) {
          totalPutts += h.putts!;
          puttCountHoles++;
        }

        if (h.penalties != null) {
          totalPenalties += h.penalties!;
        }
      }

      sumScore += roundScore;
      sumPar += roundPar;

      totalScoreByRoundId[r.id] = roundScore;
      totalParByRoundId[r.id] = roundPar;
    }

    double? pct(int hits, int opps) => opps == 0 ? null : (hits / opps) * 100.0;

    final avgScore = roundsCount == 0 ? null : (sumScore / roundsCount);
    final avgToPar =
        roundsCount == 0 ? null : ((sumScore - sumPar) / roundsCount);
    final avgPuttsPerHole =
        puttCountHoles == 0 ? null : (totalPutts / puttCountHoles);
    final avgPenaltiesPerRound =
        roundsCount == 0 ? null : (totalPenalties / roundsCount);

    final stats = _DashboardStats(
      roundsCount: roundsCount,
      avgScore: avgScore,
      avgToPar: avgToPar,
      firPct: pct(firHits, firOpps),
      girPct: pct(girHits, girOpps),
      avgPuttsPerHole: avgPuttsPerHole,
      avgPenaltiesPerRound: avgPenaltiesPerRound,
    );

    return _DashboardData(
      rounds: rounds,
      stats: stats,
      courseNameById: courseNameById,
      teeNameById: teeNameById,
      totalScoreByRoundId: totalScoreByRoundId,
      totalParByRoundId: totalParByRoundId,
    );
  }
}

class _DashboardData {
  final List<Round> rounds;
  final _DashboardStats stats;

  final Map<int, String> courseNameById;
  final Map<int, String> teeNameById;

  final Map<int, int> totalScoreByRoundId;
  final Map<int, int> totalParByRoundId;

  _DashboardData({
    required this.rounds,
    required this.stats,
    required this.courseNameById,
    required this.teeNameById,
    required this.totalScoreByRoundId,
    required this.totalParByRoundId,
  });

  factory _DashboardData.empty() => _DashboardData(
        rounds: const [],
        stats: _DashboardStats.empty(),
        courseNameById: const {},
        teeNameById: const {},
        totalScoreByRoundId: const {},
        totalParByRoundId: const {},
      );
}

class _DashboardStats {
  final int roundsCount;
  final double? avgScore;
  final double? avgToPar;
  final double? firPct;
  final double? girPct;
  final double? avgPuttsPerHole;
  final double? avgPenaltiesPerRound;

  _DashboardStats({
    required this.roundsCount,
    required this.avgScore,
    required this.avgToPar,
    required this.firPct,
    required this.girPct,
    required this.avgPuttsPerHole,
    required this.avgPenaltiesPerRound,
  });

  factory _DashboardStats.empty() => _DashboardStats(
        roundsCount: 0,
        avgScore: null,
        avgToPar: null,
        firPct: null,
        girPct: null,
        avgPuttsPerHole: null,
        avgPenaltiesPerRound: null,
      );
}

class _StatsCard extends StatelessWidget {
  final _DashboardStats s;

  const _StatsCard(this.s);

  String _fmt(double? v, {int digits = 1}) =>
      v == null ? '-' : v.toStringAsFixed(digits);

  String _fmtPct(double? v) => v == null ? '-' : '${v.toStringAsFixed(0)}%';

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Stats (${s.roundsCount} rounds)',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                _pill('Avg Score', _fmt(s.avgScore)),
                _pill(
                    'Avg To Par', s.avgToPar == null ? '-' : _fmt(s.avgToPar)),
                _pill('FIR', _fmtPct(s.firPct)),
                _pill('GIR', _fmtPct(s.girPct)),
                _pill('Putts/Hole', _fmt(s.avgPuttsPerHole)),
                _pill('Pen/Round', _fmt(s.avgPenaltiesPerRound)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _pill(String label, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.04),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: Colors.black12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('$label: ', style: const TextStyle(color: Colors.black54)),
          Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}
